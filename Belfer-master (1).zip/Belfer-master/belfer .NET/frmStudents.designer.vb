﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStudents
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmStudents))
    Me.Panel1 = New System.Windows.Forms.Panel()
    Me.lblWychowawca = New System.Windows.Forms.Label()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.lblRecord = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.txtSeek = New System.Windows.Forms.TextBox()
    Me.cbSeek = New System.Windows.Forms.ComboBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.lvUczen = New System.Windows.Forms.ListView()
    Me.pnlCommand = New System.Windows.Forms.Panel()
    Me.cmdClose = New System.Windows.Forms.Button()
    Me.cmdStrikeOut = New System.Windows.Forms.Button()
    Me.cmdNrDz = New System.Windows.Forms.Button()
    Me.cmdDelete = New System.Windows.Forms.Button()
    Me.cmdEdit = New System.Windows.Forms.Button()
    Me.cmdAddNew = New System.Windows.Forms.Button()
    Me.Panel2 = New System.Windows.Forms.Panel()
    Me.tlpDetails = New System.Windows.Forms.TableLayoutPanel()
    Me.lblDataAktywacji = New System.Windows.Forms.Label()
    Me.Label6 = New System.Windows.Forms.Label()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.Label25 = New System.Windows.Forms.Label()
    Me.Label21 = New System.Windows.Forms.Label()
    Me.Label20 = New System.Windows.Forms.Label()
    Me.Label15 = New System.Windows.Forms.Label()
    Me.lblMiejsceZam = New System.Windows.Forms.Label()
    Me.Label9 = New System.Windows.Forms.Label()
    Me.Label8 = New System.Windows.Forms.Label()
    Me.lblMiejsceUr = New System.Windows.Forms.Label()
    Me.lblPoczta = New System.Windows.Forms.Label()
    Me.lblImieOjca = New System.Windows.Forms.Label()
    Me.Label10 = New System.Windows.Forms.Label()
    Me.Label13 = New System.Windows.Forms.Label()
    Me.chkMiasto = New System.Windows.Forms.CheckBox()
    Me.lblWojUr = New System.Windows.Forms.Label()
    Me.lblUlica = New System.Windows.Forms.Label()
    Me.lblKodPocztowy = New System.Windows.Forms.Label()
    Me.lblNazwiskoOjca = New System.Windows.Forms.Label()
    Me.lblNrDomu = New System.Windows.Forms.Label()
    Me.lblWojZam = New System.Windows.Forms.Label()
    Me.lblImieMatki = New System.Windows.Forms.Label()
    Me.lblNrMieszkania = New System.Windows.Forms.Label()
    Me.Label17 = New System.Windows.Forms.Label()
    Me.Label16 = New System.Windows.Forms.Label()
    Me.Label19 = New System.Windows.Forms.Label()
    Me.Label22 = New System.Windows.Forms.Label()
    Me.Label24 = New System.Windows.Forms.Label()
    Me.Label27 = New System.Windows.Forms.Label()
    Me.lblNazwiskoMatki = New System.Windows.Forms.Label()
    Me.lblKraj = New System.Windows.Forms.Label()
    Me.lblTel1 = New System.Windows.Forms.Label()
    Me.Label18 = New System.Windows.Forms.Label()
    Me.Label23 = New System.Windows.Forms.Label()
    Me.lblTelKom1 = New System.Windows.Forms.Label()
    Me.Label26 = New System.Windows.Forms.Label()
    Me.lblTelKom2 = New System.Windows.Forms.Label()
    Me.Label11 = New System.Windows.Forms.Label()
    Me.lblDataDeaktywacji = New System.Windows.Forms.Label()
    Me.Label14 = New System.Windows.Forms.Label()
    Me.Label12 = New System.Windows.Forms.Label()
    Me.lblData = New System.Windows.Forms.Label()
    Me.lblIP = New System.Windows.Forms.Label()
    Me.lblUser = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Panel1.SuspendLayout()
    Me.pnlCommand.SuspendLayout()
    Me.Panel2.SuspendLayout()
    Me.tlpDetails.SuspendLayout()
    Me.SuspendLayout()
    '
    'Panel1
    '
    Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Panel1.BackColor = System.Drawing.SystemColors.Control
    Me.Panel1.Controls.Add(Me.lblWychowawca)
    Me.Panel1.Controls.Add(Me.Label5)
    Me.Panel1.Controls.Add(Me.lblRecord)
    Me.Panel1.Controls.Add(Me.Label2)
    Me.Panel1.Controls.Add(Me.txtSeek)
    Me.Panel1.Controls.Add(Me.cbSeek)
    Me.Panel1.Controls.Add(Me.Label1)
    Me.Panel1.Controls.Add(Me.lvUczen)
    Me.Panel1.Location = New System.Drawing.Point(12, 12)
    Me.Panel1.Name = "Panel1"
    Me.Panel1.Size = New System.Drawing.Size(740, 334)
    Me.Panel1.TabIndex = 0
    '
    'lblWychowawca
    '
    Me.lblWychowawca.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblWychowawca.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblWychowawca.ForeColor = System.Drawing.Color.Green
    Me.lblWychowawca.Location = New System.Drawing.Point(563, 314)
    Me.lblWychowawca.Name = "lblWychowawca"
    Me.lblWychowawca.Size = New System.Drawing.Size(173, 13)
    Me.lblWychowawca.TabIndex = 51
    Me.lblWychowawca.Text = "lblWychowawca"
    '
    'Label5
    '
    Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label5.AutoSize = True
    Me.Label5.Location = New System.Drawing.Point(479, 314)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(78, 13)
    Me.Label5.TabIndex = 50
    Me.Label5.Text = "Wychowawca:"
    '
    'lblRecord
    '
    Me.lblRecord.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.lblRecord.AutoSize = True
    Me.lblRecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblRecord.ForeColor = System.Drawing.Color.Red
    Me.lblRecord.Location = New System.Drawing.Point(54, 314)
    Me.lblRecord.Name = "lblRecord"
    Me.lblRecord.Size = New System.Drawing.Size(61, 13)
    Me.lblRecord.TabIndex = 49
    Me.lblRecord.Text = "lblRecord"
    '
    'Label2
    '
    Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(3, 314)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(45, 13)
    Me.Label2.TabIndex = 48
    Me.Label2.Text = "Rekord:"
    '
    'txtSeek
    '
    Me.txtSeek.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.txtSeek.Location = New System.Drawing.Point(185, 3)
    Me.txtSeek.Name = "txtSeek"
    Me.txtSeek.Size = New System.Drawing.Size(553, 20)
    Me.txtSeek.TabIndex = 47
    '
    'cbSeek
    '
    Me.cbSeek.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cbSeek.DropDownWidth = 200
    Me.cbSeek.FormattingEnabled = True
    Me.cbSeek.Location = New System.Drawing.Point(57, 2)
    Me.cbSeek.Name = "cbSeek"
    Me.cbSeek.Size = New System.Drawing.Size(122, 21)
    Me.cbSeek.TabIndex = 46
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(3, 6)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(48, 13)
    Me.Label1.TabIndex = 45
    Me.Label1.Text = "Filtruj wg"
    '
    'lvUczen
    '
    Me.lvUczen.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lvUczen.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
    Me.lvUczen.Location = New System.Drawing.Point(0, 27)
    Me.lvUczen.Name = "lvUczen"
    Me.lvUczen.Size = New System.Drawing.Size(738, 284)
    Me.lvUczen.TabIndex = 44
    Me.lvUczen.UseCompatibleStateImageBehavior = False
    '
    'pnlCommand
    '
    Me.pnlCommand.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.pnlCommand.BackColor = System.Drawing.SystemColors.Control
    Me.pnlCommand.Controls.Add(Me.cmdClose)
    Me.pnlCommand.Controls.Add(Me.cmdStrikeOut)
    Me.pnlCommand.Controls.Add(Me.cmdNrDz)
    Me.pnlCommand.Controls.Add(Me.cmdDelete)
    Me.pnlCommand.Controls.Add(Me.cmdEdit)
    Me.pnlCommand.Controls.Add(Me.cmdAddNew)
    Me.pnlCommand.Location = New System.Drawing.Point(754, 12)
    Me.pnlCommand.Name = "pnlCommand"
    Me.pnlCommand.Size = New System.Drawing.Size(105, 334)
    Me.pnlCommand.TabIndex = 1
    '
    'cmdClose
    '
    Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.cmdClose.Image = CType(resources.GetObject("cmdClose.Image"), System.Drawing.Image)
    Me.cmdClose.Location = New System.Drawing.Point(5, 276)
    Me.cmdClose.Name = "cmdClose"
    Me.cmdClose.Size = New System.Drawing.Size(97, 35)
    Me.cmdClose.TabIndex = 190
    Me.cmdClose.Text = "&Zamknij"
    Me.cmdClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    Me.cmdClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
    Me.cmdClose.UseVisualStyleBackColor = True
    '
    'cmdStrikeOut
    '
    Me.cmdStrikeOut.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.cmdStrikeOut.Enabled = False
    Me.cmdStrikeOut.Image = Global.belfer.NET.My.Resources.Resources.strikeout_24
    Me.cmdStrikeOut.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
    Me.cmdStrikeOut.Location = New System.Drawing.Point(5, 126)
    Me.cmdStrikeOut.Name = "cmdStrikeOut"
    Me.cmdStrikeOut.Size = New System.Drawing.Size(97, 35)
    Me.cmdStrikeOut.TabIndex = 53
    Me.cmdStrikeOut.Text = "&Skreśl"
    Me.cmdStrikeOut.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
    Me.cmdStrikeOut.UseVisualStyleBackColor = True
    '
    'cmdNrDz
    '
    Me.cmdNrDz.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.cmdNrDz.Enabled = False
    Me.cmdNrDz.Image = Global.belfer.NET.My.Resources.Resources.sorting_24
    Me.cmdNrDz.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
    Me.cmdNrDz.Location = New System.Drawing.Point(5, 167)
    Me.cmdNrDz.Name = "cmdNrDz"
    Me.cmdNrDz.Size = New System.Drawing.Size(97, 35)
    Me.cmdNrDz.TabIndex = 52
    Me.cmdNrDz.Text = "Nr w dzienniku"
    Me.cmdNrDz.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
    Me.cmdNrDz.UseVisualStyleBackColor = True
    '
    'cmdDelete
    '
    Me.cmdDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.cmdDelete.Enabled = False
    Me.cmdDelete.Image = Global.belfer.NET.My.Resources.Resources.del_24
    Me.cmdDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
    Me.cmdDelete.Location = New System.Drawing.Point(5, 85)
    Me.cmdDelete.Name = "cmdDelete"
    Me.cmdDelete.Size = New System.Drawing.Size(97, 35)
    Me.cmdDelete.TabIndex = 51
    Me.cmdDelete.Text = "&Usuń"
    Me.cmdDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
    '
    'cmdEdit
    '
    Me.cmdEdit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.cmdEdit.Enabled = False
    Me.cmdEdit.Image = Global.belfer.NET.My.Resources.Resources.edit
    Me.cmdEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
    Me.cmdEdit.Location = New System.Drawing.Point(5, 44)
    Me.cmdEdit.Name = "cmdEdit"
    Me.cmdEdit.Size = New System.Drawing.Size(97, 35)
    Me.cmdEdit.TabIndex = 50
    Me.cmdEdit.Text = "&Edytuj"
    Me.cmdEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
    '
    'cmdAddNew
    '
    Me.cmdAddNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.cmdAddNew.Image = Global.belfer.NET.My.Resources.Resources.add_24
    Me.cmdAddNew.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
    Me.cmdAddNew.Location = New System.Drawing.Point(5, 3)
    Me.cmdAddNew.Name = "cmdAddNew"
    Me.cmdAddNew.Size = New System.Drawing.Size(97, 35)
    Me.cmdAddNew.TabIndex = 49
    Me.cmdAddNew.Text = "&Dodaj"
    Me.cmdAddNew.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
    '
    'Panel2
    '
    Me.Panel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Panel2.BackColor = System.Drawing.SystemColors.Control
    Me.Panel2.Controls.Add(Me.tlpDetails)
    Me.Panel2.Controls.Add(Me.Label14)
    Me.Panel2.Controls.Add(Me.Label12)
    Me.Panel2.Controls.Add(Me.lblData)
    Me.Panel2.Controls.Add(Me.lblIP)
    Me.Panel2.Controls.Add(Me.lblUser)
    Me.Panel2.Controls.Add(Me.Label3)
    Me.Panel2.Location = New System.Drawing.Point(12, 352)
    Me.Panel2.Name = "Panel2"
    Me.Panel2.Size = New System.Drawing.Size(847, 151)
    Me.Panel2.TabIndex = 2
    '
    'tlpDetails
    '
    Me.tlpDetails.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.tlpDetails.ColumnCount = 8
    Me.tlpDetails.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.558102!))
    Me.tlpDetails.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.39116!))
    Me.tlpDetails.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.86743!))
    Me.tlpDetails.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.19967!))
    Me.tlpDetails.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.510637!))
    Me.tlpDetails.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.28315!))
    Me.tlpDetails.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.65303!))
    Me.tlpDetails.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.53682!))
    Me.tlpDetails.Controls.Add(Me.lblDataAktywacji, 5, 5)
    Me.tlpDetails.Controls.Add(Me.Label6, 4, 5)
    Me.tlpDetails.Controls.Add(Me.Label4, 6, 3)
    Me.tlpDetails.Controls.Add(Me.Label25, 6, 1)
    Me.tlpDetails.Controls.Add(Me.Label21, 4, 1)
    Me.tlpDetails.Controls.Add(Me.Label20, 4, 0)
    Me.tlpDetails.Controls.Add(Me.Label15, 2, 0)
    Me.tlpDetails.Controls.Add(Me.lblMiejsceZam, 1, 1)
    Me.tlpDetails.Controls.Add(Me.Label9, 0, 1)
    Me.tlpDetails.Controls.Add(Me.Label8, 0, 0)
    Me.tlpDetails.Controls.Add(Me.lblMiejsceUr, 1, 0)
    Me.tlpDetails.Controls.Add(Me.lblPoczta, 1, 2)
    Me.tlpDetails.Controls.Add(Me.lblImieOjca, 1, 4)
    Me.tlpDetails.Controls.Add(Me.Label10, 0, 2)
    Me.tlpDetails.Controls.Add(Me.Label13, 0, 4)
    Me.tlpDetails.Controls.Add(Me.chkMiasto, 7, 3)
    Me.tlpDetails.Controls.Add(Me.lblWojUr, 3, 0)
    Me.tlpDetails.Controls.Add(Me.lblUlica, 3, 1)
    Me.tlpDetails.Controls.Add(Me.lblKodPocztowy, 3, 2)
    Me.tlpDetails.Controls.Add(Me.lblNazwiskoOjca, 3, 4)
    Me.tlpDetails.Controls.Add(Me.lblNrDomu, 5, 1)
    Me.tlpDetails.Controls.Add(Me.lblWojZam, 5, 2)
    Me.tlpDetails.Controls.Add(Me.lblImieMatki, 5, 4)
    Me.tlpDetails.Controls.Add(Me.lblNrMieszkania, 7, 1)
    Me.tlpDetails.Controls.Add(Me.Label17, 2, 2)
    Me.tlpDetails.Controls.Add(Me.Label16, 2, 1)
    Me.tlpDetails.Controls.Add(Me.Label19, 2, 4)
    Me.tlpDetails.Controls.Add(Me.Label22, 4, 2)
    Me.tlpDetails.Controls.Add(Me.Label24, 4, 4)
    Me.tlpDetails.Controls.Add(Me.Label27, 6, 4)
    Me.tlpDetails.Controls.Add(Me.lblNazwiskoMatki, 7, 4)
    Me.tlpDetails.Controls.Add(Me.lblKraj, 5, 0)
    Me.tlpDetails.Controls.Add(Me.lblTel1, 1, 3)
    Me.tlpDetails.Controls.Add(Me.Label18, 0, 3)
    Me.tlpDetails.Controls.Add(Me.Label23, 2, 3)
    Me.tlpDetails.Controls.Add(Me.lblTelKom1, 3, 3)
    Me.tlpDetails.Controls.Add(Me.Label26, 4, 3)
    Me.tlpDetails.Controls.Add(Me.lblTelKom2, 5, 3)
    Me.tlpDetails.Controls.Add(Me.Label11, 6, 5)
    Me.tlpDetails.Controls.Add(Me.lblDataDeaktywacji, 7, 5)
    Me.tlpDetails.Location = New System.Drawing.Point(0, 0)
    Me.tlpDetails.Name = "tlpDetails"
    Me.tlpDetails.RowCount = 6
    Me.tlpDetails.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
    Me.tlpDetails.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
    Me.tlpDetails.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
    Me.tlpDetails.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
    Me.tlpDetails.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
    Me.tlpDetails.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
    Me.tlpDetails.Size = New System.Drawing.Size(846, 120)
    Me.tlpDetails.TabIndex = 56
    '
    'lblDataAktywacji
    '
    Me.lblDataAktywacji.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblDataAktywacji.AutoSize = True
    Me.lblDataAktywacji.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblDataAktywacji.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblDataAktywacji.Location = New System.Drawing.Point(494, 103)
    Me.lblDataAktywacji.Name = "lblDataAktywacji"
    Me.lblDataAktywacji.Size = New System.Drawing.Size(140, 13)
    Me.lblDataAktywacji.TabIndex = 97
    Me.lblDataAktywacji.Text = "DataAktywacji"
    Me.lblDataAktywacji.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'Label6
    '
    Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label6.AutoSize = True
    Me.Label6.Location = New System.Drawing.Point(423, 103)
    Me.Label6.Name = "Label6"
    Me.Label6.Size = New System.Drawing.Size(65, 13)
    Me.Label6.TabIndex = 96
    Me.Label6.Text = "Data zapisu"
    '
    'Label4
    '
    Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label4.AutoSize = True
    Me.Label4.Location = New System.Drawing.Point(640, 63)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(92, 13)
    Me.Label4.TabIndex = 95
    Me.Label4.Text = "Miasto"
    Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Label25
    '
    Me.Label25.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label25.AutoSize = True
    Me.Label25.Location = New System.Drawing.Point(640, 23)
    Me.Label25.Name = "Label25"
    Me.Label25.Size = New System.Drawing.Size(92, 13)
    Me.Label25.TabIndex = 91
    Me.Label25.Text = "Nr mieszkania"
    '
    'Label21
    '
    Me.Label21.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label21.AutoSize = True
    Me.Label21.Location = New System.Drawing.Point(423, 23)
    Me.Label21.Name = "Label21"
    Me.Label21.Size = New System.Drawing.Size(65, 13)
    Me.Label21.TabIndex = 87
    Me.Label21.Text = "Nr domu"
    '
    'Label20
    '
    Me.Label20.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label20.AutoSize = True
    Me.Label20.Location = New System.Drawing.Point(423, 3)
    Me.Label20.Name = "Label20"
    Me.Label20.Size = New System.Drawing.Size(65, 13)
    Me.Label20.TabIndex = 86
    Me.Label20.Text = "Kraj ur."
    '
    'Label15
    '
    Me.Label15.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label15.AutoSize = True
    Me.Label15.Location = New System.Drawing.Point(179, 3)
    Me.Label15.Name = "Label15"
    Me.Label15.Size = New System.Drawing.Size(85, 13)
    Me.Label15.TabIndex = 81
    Me.Label15.Text = "Woj. ur."
    '
    'lblMiejsceZam
    '
    Me.lblMiejsceZam.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblMiejsceZam.AutoSize = True
    Me.lblMiejsceZam.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblMiejsceZam.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblMiejsceZam.Location = New System.Drawing.Point(83, 23)
    Me.lblMiejsceZam.Name = "lblMiejsceZam"
    Me.lblMiejsceZam.Size = New System.Drawing.Size(90, 13)
    Me.lblMiejsceZam.TabIndex = 53
    Me.lblMiejsceZam.Text = "miejsce zam."
    '
    'Label9
    '
    Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label9.AutoSize = True
    Me.Label9.Location = New System.Drawing.Point(3, 23)
    Me.Label9.Name = "Label9"
    Me.Label9.Size = New System.Drawing.Size(74, 13)
    Me.Label9.TabIndex = 72
    Me.Label9.Text = "miejsce zam"
    '
    'Label8
    '
    Me.Label8.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label8.AutoSize = True
    Me.Label8.Location = New System.Drawing.Point(3, 3)
    Me.Label8.Name = "Label8"
    Me.Label8.Size = New System.Drawing.Size(74, 13)
    Me.Label8.TabIndex = 71
    Me.Label8.Text = "Miejsce ur."
    '
    'lblMiejsceUr
    '
    Me.lblMiejsceUr.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblMiejsceUr.AutoSize = True
    Me.lblMiejsceUr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblMiejsceUr.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblMiejsceUr.Location = New System.Drawing.Point(83, 3)
    Me.lblMiejsceUr.Name = "lblMiejsceUr"
    Me.lblMiejsceUr.Size = New System.Drawing.Size(90, 13)
    Me.lblMiejsceUr.TabIndex = 50
    Me.lblMiejsceUr.Text = "Miejsce ur: "
    '
    'lblPoczta
    '
    Me.lblPoczta.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblPoczta.AutoSize = True
    Me.lblPoczta.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblPoczta.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblPoczta.Location = New System.Drawing.Point(83, 43)
    Me.lblPoczta.Name = "lblPoczta"
    Me.lblPoczta.Size = New System.Drawing.Size(90, 13)
    Me.lblPoczta.TabIndex = 58
    Me.lblPoczta.Text = "Poczta"
    '
    'lblImieOjca
    '
    Me.lblImieOjca.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblImieOjca.AutoSize = True
    Me.lblImieOjca.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblImieOjca.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblImieOjca.Location = New System.Drawing.Point(83, 83)
    Me.lblImieOjca.Name = "lblImieOjca"
    Me.lblImieOjca.Size = New System.Drawing.Size(90, 13)
    Me.lblImieOjca.TabIndex = 66
    Me.lblImieOjca.Text = "Imię ojca"
    '
    'Label10
    '
    Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label10.AutoSize = True
    Me.Label10.Location = New System.Drawing.Point(3, 43)
    Me.Label10.Name = "Label10"
    Me.Label10.Size = New System.Drawing.Size(74, 13)
    Me.Label10.TabIndex = 73
    Me.Label10.Text = "Poczta"
    '
    'Label13
    '
    Me.Label13.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label13.AutoSize = True
    Me.Label13.Location = New System.Drawing.Point(3, 83)
    Me.Label13.Name = "Label13"
    Me.Label13.Size = New System.Drawing.Size(74, 13)
    Me.Label13.TabIndex = 75
    Me.Label13.Text = "Imię ojca"
    '
    'chkMiasto
    '
    Me.chkMiasto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.chkMiasto.Enabled = False
    Me.chkMiasto.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.chkMiasto.ForeColor = System.Drawing.SystemColors.MenuText
    Me.chkMiasto.Location = New System.Drawing.Point(743, 63)
    Me.chkMiasto.Name = "chkMiasto"
    Me.chkMiasto.Size = New System.Drawing.Size(100, 14)
    Me.chkMiasto.TabIndex = 63
    Me.chkMiasto.UseVisualStyleBackColor = True
    '
    'lblWojUr
    '
    Me.lblWojUr.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblWojUr.AutoSize = True
    Me.lblWojUr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblWojUr.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblWojUr.Location = New System.Drawing.Point(270, 3)
    Me.lblWojUr.Name = "lblWojUr"
    Me.lblWojUr.Size = New System.Drawing.Size(147, 13)
    Me.lblWojUr.TabIndex = 51
    Me.lblWojUr.Text = "Woj. ur."
    '
    'lblUlica
    '
    Me.lblUlica.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblUlica.AutoSize = True
    Me.lblUlica.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblUlica.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblUlica.Location = New System.Drawing.Point(270, 23)
    Me.lblUlica.Name = "lblUlica"
    Me.lblUlica.Size = New System.Drawing.Size(147, 13)
    Me.lblUlica.TabIndex = 55
    Me.lblUlica.Text = "Ulica"
    '
    'lblKodPocztowy
    '
    Me.lblKodPocztowy.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblKodPocztowy.AutoSize = True
    Me.lblKodPocztowy.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblKodPocztowy.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblKodPocztowy.Location = New System.Drawing.Point(270, 43)
    Me.lblKodPocztowy.Name = "lblKodPocztowy"
    Me.lblKodPocztowy.Size = New System.Drawing.Size(147, 13)
    Me.lblKodPocztowy.TabIndex = 59
    Me.lblKodPocztowy.Text = "Kod pocztowy"
    '
    'lblNazwiskoOjca
    '
    Me.lblNazwiskoOjca.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblNazwiskoOjca.AutoSize = True
    Me.lblNazwiskoOjca.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblNazwiskoOjca.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblNazwiskoOjca.Location = New System.Drawing.Point(270, 83)
    Me.lblNazwiskoOjca.Name = "lblNazwiskoOjca"
    Me.lblNazwiskoOjca.Size = New System.Drawing.Size(147, 13)
    Me.lblNazwiskoOjca.TabIndex = 70
    Me.lblNazwiskoOjca.Text = "Nazwisko ojca"
    '
    'lblNrDomu
    '
    Me.lblNrDomu.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblNrDomu.AutoSize = True
    Me.lblNrDomu.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblNrDomu.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblNrDomu.Location = New System.Drawing.Point(494, 23)
    Me.lblNrDomu.Name = "lblNrDomu"
    Me.lblNrDomu.Size = New System.Drawing.Size(140, 13)
    Me.lblNrDomu.TabIndex = 56
    Me.lblNrDomu.Text = "Nr domu"
    '
    'lblWojZam
    '
    Me.lblWojZam.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblWojZam.AutoSize = True
    Me.tlpDetails.SetColumnSpan(Me.lblWojZam, 2)
    Me.lblWojZam.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblWojZam.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblWojZam.Location = New System.Drawing.Point(494, 43)
    Me.lblWojZam.Name = "lblWojZam"
    Me.lblWojZam.Size = New System.Drawing.Size(238, 13)
    Me.lblWojZam.TabIndex = 60
    Me.lblWojZam.Text = "Woj zam."
    '
    'lblImieMatki
    '
    Me.lblImieMatki.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblImieMatki.AutoSize = True
    Me.lblImieMatki.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblImieMatki.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblImieMatki.Location = New System.Drawing.Point(494, 83)
    Me.lblImieMatki.Name = "lblImieMatki"
    Me.lblImieMatki.Size = New System.Drawing.Size(140, 13)
    Me.lblImieMatki.TabIndex = 67
    Me.lblImieMatki.Text = "Imię matki"
    '
    'lblNrMieszkania
    '
    Me.lblNrMieszkania.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblNrMieszkania.AutoSize = True
    Me.lblNrMieszkania.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblNrMieszkania.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblNrMieszkania.Location = New System.Drawing.Point(738, 23)
    Me.lblNrMieszkania.Name = "lblNrMieszkania"
    Me.lblNrMieszkania.Size = New System.Drawing.Size(105, 13)
    Me.lblNrMieszkania.TabIndex = 57
    Me.lblNrMieszkania.Text = "Nr mieszkania"
    '
    'Label17
    '
    Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label17.AutoSize = True
    Me.Label17.Location = New System.Drawing.Point(179, 43)
    Me.Label17.Name = "Label17"
    Me.Label17.Size = New System.Drawing.Size(85, 13)
    Me.Label17.TabIndex = 83
    Me.Label17.Text = "Kod pocztowy"
    '
    'Label16
    '
    Me.Label16.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label16.AutoSize = True
    Me.Label16.Location = New System.Drawing.Point(179, 23)
    Me.Label16.Name = "Label16"
    Me.Label16.Size = New System.Drawing.Size(85, 13)
    Me.Label16.TabIndex = 82
    Me.Label16.Text = "Ulica"
    '
    'Label19
    '
    Me.Label19.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label19.AutoSize = True
    Me.Label19.Location = New System.Drawing.Point(179, 83)
    Me.Label19.Name = "Label19"
    Me.Label19.Size = New System.Drawing.Size(85, 13)
    Me.Label19.TabIndex = 85
    Me.Label19.Text = "Nazwisko ojca"
    '
    'Label22
    '
    Me.Label22.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label22.AutoSize = True
    Me.Label22.Location = New System.Drawing.Point(423, 43)
    Me.Label22.Name = "Label22"
    Me.Label22.Size = New System.Drawing.Size(65, 13)
    Me.Label22.TabIndex = 88
    Me.Label22.Text = "Woj zam."
    '
    'Label24
    '
    Me.Label24.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label24.AutoSize = True
    Me.Label24.Location = New System.Drawing.Point(423, 83)
    Me.Label24.Name = "Label24"
    Me.Label24.Size = New System.Drawing.Size(65, 13)
    Me.Label24.TabIndex = 90
    Me.Label24.Text = "Imię matki"
    '
    'Label27
    '
    Me.Label27.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label27.AutoSize = True
    Me.Label27.Location = New System.Drawing.Point(640, 83)
    Me.Label27.Name = "Label27"
    Me.Label27.Size = New System.Drawing.Size(92, 13)
    Me.Label27.TabIndex = 93
    Me.Label27.Text = "Nazwisko matki"
    '
    'lblNazwiskoMatki
    '
    Me.lblNazwiskoMatki.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblNazwiskoMatki.AutoSize = True
    Me.lblNazwiskoMatki.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblNazwiskoMatki.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblNazwiskoMatki.Location = New System.Drawing.Point(738, 83)
    Me.lblNazwiskoMatki.Name = "lblNazwiskoMatki"
    Me.lblNazwiskoMatki.Size = New System.Drawing.Size(105, 13)
    Me.lblNazwiskoMatki.TabIndex = 94
    Me.lblNazwiskoMatki.Text = "NazwiskoM"
    '
    'lblKraj
    '
    Me.lblKraj.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblKraj.AutoSize = True
    Me.lblKraj.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblKraj.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblKraj.Location = New System.Drawing.Point(494, 3)
    Me.lblKraj.Name = "lblKraj"
    Me.lblKraj.Size = New System.Drawing.Size(140, 13)
    Me.lblKraj.TabIndex = 62
    Me.lblKraj.Text = "Kraj"
    '
    'lblTel1
    '
    Me.lblTel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblTel1.AutoSize = True
    Me.lblTel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblTel1.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblTel1.Location = New System.Drawing.Point(83, 63)
    Me.lblTel1.Name = "lblTel1"
    Me.lblTel1.Size = New System.Drawing.Size(90, 13)
    Me.lblTel1.TabIndex = 61
    Me.lblTel1.Text = "Tel. 1"
    '
    'Label18
    '
    Me.Label18.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label18.AutoSize = True
    Me.Label18.Location = New System.Drawing.Point(3, 63)
    Me.Label18.Name = "Label18"
    Me.Label18.Size = New System.Drawing.Size(74, 13)
    Me.Label18.TabIndex = 84
    Me.Label18.Text = "Tel. 1"
    '
    'Label23
    '
    Me.Label23.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label23.AutoSize = True
    Me.Label23.Location = New System.Drawing.Point(179, 63)
    Me.Label23.Name = "Label23"
    Me.Label23.Size = New System.Drawing.Size(85, 13)
    Me.Label23.TabIndex = 89
    Me.Label23.Text = "Tel. kom 1"
    '
    'lblTelKom1
    '
    Me.lblTelKom1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblTelKom1.AutoSize = True
    Me.lblTelKom1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblTelKom1.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblTelKom1.Location = New System.Drawing.Point(270, 63)
    Me.lblTelKom1.Name = "lblTelKom1"
    Me.lblTelKom1.Size = New System.Drawing.Size(147, 13)
    Me.lblTelKom1.TabIndex = 64
    Me.lblTelKom1.Text = "Tel. kom 1"
    '
    'Label26
    '
    Me.Label26.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label26.AutoSize = True
    Me.Label26.Location = New System.Drawing.Point(423, 63)
    Me.Label26.Name = "Label26"
    Me.Label26.Size = New System.Drawing.Size(65, 13)
    Me.Label26.TabIndex = 92
    Me.Label26.Text = "Tel. kom 2"
    '
    'lblTelKom2
    '
    Me.lblTelKom2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblTelKom2.AutoSize = True
    Me.lblTelKom2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblTelKom2.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblTelKom2.Location = New System.Drawing.Point(494, 63)
    Me.lblTelKom2.Name = "lblTelKom2"
    Me.lblTelKom2.Size = New System.Drawing.Size(140, 13)
    Me.lblTelKom2.TabIndex = 65
    Me.lblTelKom2.Text = "Tel. kom 2"
    '
    'Label11
    '
    Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Label11.AutoSize = True
    Me.Label11.Location = New System.Drawing.Point(640, 103)
    Me.Label11.Name = "Label11"
    Me.Label11.Size = New System.Drawing.Size(92, 13)
    Me.Label11.TabIndex = 74
    Me.Label11.Text = "Data skreślenia"
    '
    'lblDataDeaktywacji
    '
    Me.lblDataDeaktywacji.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lblDataDeaktywacji.AutoSize = True
    Me.lblDataDeaktywacji.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
    Me.lblDataDeaktywacji.ForeColor = System.Drawing.SystemColors.HotTrack
    Me.lblDataDeaktywacji.Location = New System.Drawing.Point(738, 103)
    Me.lblDataDeaktywacji.Name = "lblDataDeaktywacji"
    Me.lblDataDeaktywacji.Size = New System.Drawing.Size(105, 13)
    Me.lblDataDeaktywacji.TabIndex = 52
    Me.lblDataDeaktywacji.Text = "DataDeaktywacji"
    Me.lblDataDeaktywacji.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'Label14
    '
    Me.Label14.AutoSize = True
    Me.Label14.Enabled = False
    Me.Label14.Location = New System.Drawing.Point(632, 131)
    Me.Label14.Name = "Label14"
    Me.Label14.Size = New System.Drawing.Size(85, 13)
    Me.Label14.TabIndex = 54
    Me.Label14.Text = "Data modyfikacji"
    '
    'Label12
    '
    Me.Label12.AutoSize = True
    Me.Label12.Enabled = False
    Me.Label12.Location = New System.Drawing.Point(489, 131)
    Me.Label12.Name = "Label12"
    Me.Label12.Size = New System.Drawing.Size(31, 13)
    Me.Label12.TabIndex = 53
    Me.Label12.Text = "Nr IP"
    '
    'lblData
    '
    Me.lblData.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblData.Enabled = False
    Me.lblData.Location = New System.Drawing.Point(723, 126)
    Me.lblData.Name = "lblData"
    Me.lblData.Size = New System.Drawing.Size(120, 23)
    Me.lblData.TabIndex = 52
    Me.lblData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'lblIP
    '
    Me.lblIP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblIP.Enabled = False
    Me.lblIP.Location = New System.Drawing.Point(526, 126)
    Me.lblIP.Name = "lblIP"
    Me.lblIP.Size = New System.Drawing.Size(100, 23)
    Me.lblIP.TabIndex = 50
    Me.lblIP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'lblUser
    '
    Me.lblUser.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblUser.Enabled = False
    Me.lblUser.Location = New System.Drawing.Point(83, 126)
    Me.lblUser.Name = "lblUser"
    Me.lblUser.Size = New System.Drawing.Size(400, 23)
    Me.lblUser.TabIndex = 51
    Me.lblUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Enabled = False
    Me.Label3.Location = New System.Drawing.Point(3, 131)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(74, 13)
    Me.Label3.TabIndex = 49
    Me.Label3.Text = "Zmodyfikował"
    '
    'frmStudents
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(871, 515)
    Me.Controls.Add(Me.Panel2)
    Me.Controls.Add(Me.pnlCommand)
    Me.Controls.Add(Me.Panel1)
    Me.Name = "frmStudents"
    Me.Text = "Dane personalne uczniów"
    Me.Panel1.ResumeLayout(False)
    Me.Panel1.PerformLayout()
    Me.pnlCommand.ResumeLayout(False)
    Me.Panel2.ResumeLayout(False)
    Me.Panel2.PerformLayout()
    Me.tlpDetails.ResumeLayout(False)
    Me.tlpDetails.PerformLayout()
    Me.ResumeLayout(False)

  End Sub
  Friend WithEvents Panel1 As System.Windows.Forms.Panel
  Friend WithEvents pnlCommand As System.Windows.Forms.Panel
  Friend WithEvents cmdNrDz As System.Windows.Forms.Button
  Friend WithEvents cmdDelete As System.Windows.Forms.Button
  Friend WithEvents cmdEdit As System.Windows.Forms.Button
  Friend WithEvents cmdAddNew As System.Windows.Forms.Button
  Friend WithEvents lvUczen As System.Windows.Forms.ListView
  Friend WithEvents txtSeek As System.Windows.Forms.TextBox
  Friend WithEvents cbSeek As System.Windows.Forms.ComboBox
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents Panel2 As System.Windows.Forms.Panel
  Friend WithEvents Label14 As System.Windows.Forms.Label
  Friend WithEvents Label12 As System.Windows.Forms.Label
  Friend WithEvents lblData As System.Windows.Forms.Label
  Friend WithEvents lblIP As System.Windows.Forms.Label
  Friend WithEvents lblUser As System.Windows.Forms.Label
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents lblRecord As System.Windows.Forms.Label
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents lblWychowawca As System.Windows.Forms.Label
  Friend WithEvents Label5 As System.Windows.Forms.Label
  Friend WithEvents tlpDetails As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents lblMiejsceUr As System.Windows.Forms.Label
  Friend WithEvents lblWojUr As System.Windows.Forms.Label
  Friend WithEvents lblMiejsceZam As System.Windows.Forms.Label
  Friend WithEvents chkMiasto As System.Windows.Forms.CheckBox
  Friend WithEvents lblWojZam As System.Windows.Forms.Label
  Friend WithEvents lblKodPocztowy As System.Windows.Forms.Label
  Friend WithEvents lblPoczta As System.Windows.Forms.Label
  Friend WithEvents lblNrMieszkania As System.Windows.Forms.Label
  Friend WithEvents lblNrDomu As System.Windows.Forms.Label
  Friend WithEvents lblUlica As System.Windows.Forms.Label
  Friend WithEvents lblTel1 As System.Windows.Forms.Label
  Friend WithEvents lblKraj As System.Windows.Forms.Label
  Friend WithEvents lblNazwiskoOjca As System.Windows.Forms.Label
  Friend WithEvents lblImieOjca As System.Windows.Forms.Label
  Friend WithEvents lblTelKom2 As System.Windows.Forms.Label
  Friend WithEvents lblTelKom1 As System.Windows.Forms.Label
  Friend WithEvents lblImieMatki As System.Windows.Forms.Label
  Friend WithEvents Label8 As System.Windows.Forms.Label
  Friend WithEvents Label9 As System.Windows.Forms.Label
  Friend WithEvents Label10 As System.Windows.Forms.Label
  Friend WithEvents Label13 As System.Windows.Forms.Label
  Friend WithEvents Label25 As System.Windows.Forms.Label
  Friend WithEvents Label21 As System.Windows.Forms.Label
  Friend WithEvents Label20 As System.Windows.Forms.Label
  Friend WithEvents Label15 As System.Windows.Forms.Label
  Friend WithEvents Label17 As System.Windows.Forms.Label
  Friend WithEvents Label16 As System.Windows.Forms.Label
  Friend WithEvents Label18 As System.Windows.Forms.Label
  Friend WithEvents Label19 As System.Windows.Forms.Label
  Friend WithEvents Label22 As System.Windows.Forms.Label
  Friend WithEvents Label23 As System.Windows.Forms.Label
  Friend WithEvents Label24 As System.Windows.Forms.Label
  Friend WithEvents Label27 As System.Windows.Forms.Label
  Friend WithEvents Label26 As System.Windows.Forms.Label
  Friend WithEvents lblNazwiskoMatki As System.Windows.Forms.Label
  Friend WithEvents cmdStrikeOut As System.Windows.Forms.Button
  Friend WithEvents cmdClose As System.Windows.Forms.Button
  Friend WithEvents Label11 As System.Windows.Forms.Label
  Friend WithEvents lblDataDeaktywacji As System.Windows.Forms.Label
  Friend WithEvents Label4 As System.Windows.Forms.Label
  Friend WithEvents lblDataAktywacji As System.Windows.Forms.Label
  Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
