﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
    Me.MainMenuToolStrip = New System.Windows.Forms.MenuStrip()
    Me.PlikToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.WylogujToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
    Me.ImportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
    Me.ZamknijToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.UczniowieToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.DanePersonalneToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
    Me.PrzydzialUczniowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.GrupyPrzedmiotoweToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator28 = New System.Windows.Forms.ToolStripSeparator()
    Me.PromocjaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.DziennikToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.TematToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.TematByDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.TematByBelferToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator26 = New System.Windows.Forms.ToolStripSeparator()
    Me.OcenyCzastkoweToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.OcenyZachowanieToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PoprawkaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.StudentMakeupAllowedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.WynikiPoprawkoweToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
    Me.AbsencjaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.UwagiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
    Me.ZagrozeniaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.OsiagnieciaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
    Me.ProjektyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.StudentProjektToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.TematProjektToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator21 = New System.Windows.Forms.ToolStripSeparator()
    Me.PlanLekcjiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.TerminarzToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.StatystykiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.LiczbaGodzinToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.LiczbaGodzinWgKlasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.LiczbaGodzinWgNauczycielaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator33 = New System.Windows.Forms.ToolStripSeparator()
    Me.AnalizaOcenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.TableSetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.KlasyfikacjaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator40 = New System.Windows.Forms.ToolStripSeparator()
    Me.WykazNdstToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.WykazNdpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator32 = New System.Windows.Forms.ToolStripSeparator()
    Me.NauczanieIndywidualneToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator34 = New System.Windows.Forms.ToolStripSeparator()
    Me.AbsencjaByMonthToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.FrekwencjaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ReklamacjaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator36 = New System.Windows.Forms.ToolStripSeparator()
    Me.ParentLoggingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.RaportyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ListaUczniowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
    Me.WynikiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ZagrozeniaRaportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
    Me.AbsencjaRaportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.UwagiRaportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
    Me.SwiadectwaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.UstawieniaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.KonfiguracjaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ZmianahasłaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
    Me.SzkolyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PrzydzialToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PrzydzialKlasDoSzkolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PrzydzialPrzedmiotowDoSzkolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PrzydzialNauczycieliDoSzkolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PrzydzialWychowawstwToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ObsadaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
    Me.SlownikToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.MiejscowoscToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.WojewodztwaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.KrajeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
    Me.TypySzkolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.OddzialyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PrzedmiotyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
    Me.NauczycieleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator20 = New System.Windows.Forms.ToolStripSeparator()
    Me.SkalaOcenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.OpisyOcenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.HarmonogramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.KolumnyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator()
    Me.UstawieniaSwiadectwToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PierwszaStronaSwiadectwaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.KryteriaPasekToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator()
    Me.CzcionkiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.KalibracjaWydrukuSwiadectwToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator()
    Me.SzablonyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.SymboleSwiadectwToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.DefinicjeSzablonowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PowiazwaniaSzablonowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator18 = New System.Windows.Forms.ToolStripSeparator()
    Me.ImportSzablonuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ExportSzablonuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator19 = New System.Windows.Forms.ToolStripSeparator()
    Me.KalkulatorTekstuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.OpcjeSwiadectwaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator29 = New System.Windows.Forms.ToolStripSeparator()
    Me.KalibracjaWydrukuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.NadzorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ZastepstwoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ManagePlanLekcjiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.MinLekcjaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator39 = New System.Windows.Forms.ToolStripSeparator()
    Me.ZestawienieKlasyfikacjiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.UzasadnieniaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator30 = New System.Windows.Forms.ToolStripSeparator()
    Me.UserActivityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.AdminToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ApplicationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator35 = New System.Windows.Forms.ToolStripSeparator()
    Me.ZarzadzanieuzytkownikamiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ZmianaHasla2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator37 = New System.Windows.Forms.ToolStripSeparator()
    Me.UprawnieniaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.OutofdatePrivilageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
    Me.LoggingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.CurrentConnectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator38 = New System.Windows.Forms.ToolStripSeparator()
    Me.ServiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.MoveResultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.LockResultColumnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.SQLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.tblStatus = New System.Windows.Forms.TableLayoutPanel()
    Me.MainStatus = New System.Windows.Forms.StatusStrip()
    Me.statSSLMode = New System.Windows.Forms.ToolStripStatusLabel()
    Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
    Me.StatConn = New System.Windows.Forms.ToolStripStatusLabel()
    Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
    Me.StatUser = New System.Windows.Forms.ToolStripStatusLabel()
    Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
    Me.statRole = New System.Windows.Forms.ToolStripStatusLabel()
    Me.SubStatus = New System.Windows.Forms.StatusStrip()
    Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
    Me.statServer = New System.Windows.Forms.ToolStripStatusLabel()
    Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
    Me.statBaza = New System.Windows.Forms.ToolStripStatusLabel()
    Me.tlpCommonData = New System.Windows.Forms.TableLayoutPanel()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.lblRokSzkolny = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.lblSchoolName = New System.Windows.Forms.Label()
    Me.ToolStripSeparator27 = New System.Windows.Forms.ToolStripSeparator()
    Me.ToolStripSeparator31 = New System.Windows.Forms.ToolStripSeparator()
    Me.ToolStripSeparator22 = New System.Windows.Forms.ToolStripSeparator()
    Me.ToolStripSeparator23 = New System.Windows.Forms.ToolStripSeparator()
    Me.ToolStripSeparator24 = New System.Windows.Forms.ToolStripSeparator()
    Me.ToolStripSeparator25 = New System.Windows.Forms.ToolStripSeparator()
    Me.QuickAccessToolStrip = New System.Windows.Forms.ToolStrip()
    Me.cmdTerminarz = New System.Windows.Forms.ToolStripButton()
    Me.cmdTemat = New System.Windows.Forms.ToolStripButton()
    Me.cmdTematByNauczyciel = New System.Windows.Forms.ToolStripButton()
    Me.cmdWynikiCzastkowe = New System.Windows.Forms.ToolStripButton()
    Me.cmdOcenyZachowania = New System.Windows.Forms.ToolStripButton()
    Me.cmdAbsencja = New System.Windows.Forms.ToolStripButton()
    Me.cmdUwaga = New System.Windows.Forms.ToolStripButton()
    Me.cmdZagrozenia = New System.Windows.Forms.ToolStripButton()
    Me.KonfiguracjaToolStripButton = New System.Windows.Forms.ToolStripButton()
    Me.cmdWyloguj = New System.Windows.Forms.ToolStripButton()
    Me.cmdCloseProgram = New System.Windows.Forms.ToolStripButton()
    Me.MainMenuToolStrip.SuspendLayout()
    Me.tblStatus.SuspendLayout()
    Me.MainStatus.SuspendLayout()
    Me.SubStatus.SuspendLayout()
    Me.tlpCommonData.SuspendLayout()
    Me.QuickAccessToolStrip.SuspendLayout()
    Me.SuspendLayout()
    '
    'MainMenuToolStrip
    '
    Me.MainMenuToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlikToolStripMenuItem, Me.UczniowieToolStripMenuItem, Me.DziennikToolStripMenuItem, Me.StatystykiToolStripMenuItem, Me.RaportyToolStripMenuItem, Me.UstawieniaToolStripMenuItem, Me.NadzorToolStripMenuItem, Me.AdminToolStripMenuItem, Me.ProgramToolStripMenuItem})
    resources.ApplyResources(Me.MainMenuToolStrip, "MainMenuToolStrip")
    Me.MainMenuToolStrip.Name = "MainMenuToolStrip"
    '
    'PlikToolStripMenuItem
    '
    Me.PlikToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WylogujToolStripMenuItem, Me.ToolStripSeparator12, Me.ImportToolStripMenuItem, Me.ToolStripSeparator7, Me.ZamknijToolStripMenuItem})
    resources.ApplyResources(Me.PlikToolStripMenuItem, "PlikToolStripMenuItem")
    Me.PlikToolStripMenuItem.Name = "PlikToolStripMenuItem"
    '
    'WylogujToolStripMenuItem
    '
    resources.ApplyResources(Me.WylogujToolStripMenuItem, "WylogujToolStripMenuItem")
    Me.WylogujToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.logoutuser
    Me.WylogujToolStripMenuItem.Name = "WylogujToolStripMenuItem"
    '
    'ToolStripSeparator12
    '
    Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
    resources.ApplyResources(Me.ToolStripSeparator12, "ToolStripSeparator12")
    '
    'ImportToolStripMenuItem
    '
    resources.ApplyResources(Me.ImportToolStripMenuItem, "ImportToolStripMenuItem")
    Me.ImportToolStripMenuItem.Name = "ImportToolStripMenuItem"
    '
    'ToolStripSeparator7
    '
    Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
    resources.ApplyResources(Me.ToolStripSeparator7, "ToolStripSeparator7")
    '
    'ZamknijToolStripMenuItem
    '
    Me.ZamknijToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.exit_48
    Me.ZamknijToolStripMenuItem.Name = "ZamknijToolStripMenuItem"
    resources.ApplyResources(Me.ZamknijToolStripMenuItem, "ZamknijToolStripMenuItem")
    '
    'UczniowieToolStripMenuItem
    '
    Me.UczniowieToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DanePersonalneToolStripMenuItem, Me.ToolStripSeparator8, Me.PrzydzialUczniowToolStripMenuItem, Me.GrupyPrzedmiotoweToolStripMenuItem, Me.ToolStripSeparator28, Me.PromocjaToolStripMenuItem})
    resources.ApplyResources(Me.UczniowieToolStripMenuItem, "UczniowieToolStripMenuItem")
    Me.UczniowieToolStripMenuItem.Name = "UczniowieToolStripMenuItem"
    '
    'DanePersonalneToolStripMenuItem
    '
    Me.DanePersonalneToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.personal_48
    Me.DanePersonalneToolStripMenuItem.Name = "DanePersonalneToolStripMenuItem"
    resources.ApplyResources(Me.DanePersonalneToolStripMenuItem, "DanePersonalneToolStripMenuItem")
    '
    'ToolStripSeparator8
    '
    Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
    resources.ApplyResources(Me.ToolStripSeparator8, "ToolStripSeparator8")
    '
    'PrzydzialUczniowToolStripMenuItem
    '
    resources.ApplyResources(Me.PrzydzialUczniowToolStripMenuItem, "PrzydzialUczniowToolStripMenuItem")
    Me.PrzydzialUczniowToolStripMenuItem.Name = "PrzydzialUczniowToolStripMenuItem"
    '
    'GrupyPrzedmiotoweToolStripMenuItem
    '
    resources.ApplyResources(Me.GrupyPrzedmiotoweToolStripMenuItem, "GrupyPrzedmiotoweToolStripMenuItem")
    Me.GrupyPrzedmiotoweToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.group4_meeting_dark_48
    Me.GrupyPrzedmiotoweToolStripMenuItem.Name = "GrupyPrzedmiotoweToolStripMenuItem"
    '
    'ToolStripSeparator28
    '
    Me.ToolStripSeparator28.Name = "ToolStripSeparator28"
    resources.ApplyResources(Me.ToolStripSeparator28, "ToolStripSeparator28")
    '
    'PromocjaToolStripMenuItem
    '
    resources.ApplyResources(Me.PromocjaToolStripMenuItem, "PromocjaToolStripMenuItem")
    Me.PromocjaToolStripMenuItem.Name = "PromocjaToolStripMenuItem"
    '
    'DziennikToolStripMenuItem
    '
    Me.DziennikToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TematToolStripMenuItem, Me.ToolStripSeparator26, Me.OcenyCzastkoweToolStripMenuItem, Me.OcenyZachowanieToolStripMenuItem, Me.PoprawkaToolStripMenuItem, Me.ToolStripSeparator10, Me.AbsencjaToolStripMenuItem, Me.UwagiToolStripMenuItem, Me.ToolStripSeparator4, Me.ZagrozeniaToolStripMenuItem, Me.OsiagnieciaToolStripMenuItem, Me.ToolStripSeparator6, Me.ProjektyToolStripMenuItem, Me.ToolStripSeparator21, Me.PlanLekcjiToolStripMenuItem, Me.TerminarzToolStripMenuItem})
    resources.ApplyResources(Me.DziennikToolStripMenuItem, "DziennikToolStripMenuItem")
    Me.DziennikToolStripMenuItem.Name = "DziennikToolStripMenuItem"
    '
    'TematToolStripMenuItem
    '
    Me.TematToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TematByDataToolStripMenuItem, Me.TematByBelferToolStripMenuItem})
    Me.TematToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.temat
    Me.TematToolStripMenuItem.Name = "TematToolStripMenuItem"
    resources.ApplyResources(Me.TematToolStripMenuItem, "TematToolStripMenuItem")
    '
    'TematByDataToolStripMenuItem
    '
    Me.TematByDataToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.tematByData
    Me.TematByDataToolStripMenuItem.Name = "TematByDataToolStripMenuItem"
    resources.ApplyResources(Me.TematByDataToolStripMenuItem, "TematByDataToolStripMenuItem")
    '
    'TematByBelferToolStripMenuItem
    '
    Me.TematByBelferToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.tematByPrzedmiot
    Me.TematByBelferToolStripMenuItem.Name = "TematByBelferToolStripMenuItem"
    resources.ApplyResources(Me.TematByBelferToolStripMenuItem, "TematByBelferToolStripMenuItem")
    '
    'ToolStripSeparator26
    '
    Me.ToolStripSeparator26.Name = "ToolStripSeparator26"
    resources.ApplyResources(Me.ToolStripSeparator26, "ToolStripSeparator26")
    '
    'OcenyCzastkoweToolStripMenuItem
    '
    resources.ApplyResources(Me.OcenyCzastkoweToolStripMenuItem, "OcenyCzastkoweToolStripMenuItem")
    Me.OcenyCzastkoweToolStripMenuItem.Name = "OcenyCzastkoweToolStripMenuItem"
    '
    'OcenyZachowanieToolStripMenuItem
    '
    Me.OcenyZachowanieToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.zachowanie
    Me.OcenyZachowanieToolStripMenuItem.Name = "OcenyZachowanieToolStripMenuItem"
    resources.ApplyResources(Me.OcenyZachowanieToolStripMenuItem, "OcenyZachowanieToolStripMenuItem")
    '
    'PoprawkaToolStripMenuItem
    '
    Me.PoprawkaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentMakeupAllowedToolStripMenuItem, Me.WynikiPoprawkoweToolStripMenuItem})
    Me.PoprawkaToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.exam
    Me.PoprawkaToolStripMenuItem.Name = "PoprawkaToolStripMenuItem"
    resources.ApplyResources(Me.PoprawkaToolStripMenuItem, "PoprawkaToolStripMenuItem")
    '
    'StudentMakeupAllowedToolStripMenuItem
    '
    Me.StudentMakeupAllowedToolStripMenuItem.Name = "StudentMakeupAllowedToolStripMenuItem"
    resources.ApplyResources(Me.StudentMakeupAllowedToolStripMenuItem, "StudentMakeupAllowedToolStripMenuItem")
    '
    'WynikiPoprawkoweToolStripMenuItem
    '
    Me.WynikiPoprawkoweToolStripMenuItem.Name = "WynikiPoprawkoweToolStripMenuItem"
    resources.ApplyResources(Me.WynikiPoprawkoweToolStripMenuItem, "WynikiPoprawkoweToolStripMenuItem")
    '
    'ToolStripSeparator10
    '
    Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
    resources.ApplyResources(Me.ToolStripSeparator10, "ToolStripSeparator10")
    '
    'AbsencjaToolStripMenuItem
    '
    resources.ApplyResources(Me.AbsencjaToolStripMenuItem, "AbsencjaToolStripMenuItem")
    Me.AbsencjaToolStripMenuItem.Name = "AbsencjaToolStripMenuItem"
    '
    'UwagiToolStripMenuItem
    '
    resources.ApplyResources(Me.UwagiToolStripMenuItem, "UwagiToolStripMenuItem")
    Me.UwagiToolStripMenuItem.Name = "UwagiToolStripMenuItem"
    '
    'ToolStripSeparator4
    '
    Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
    resources.ApplyResources(Me.ToolStripSeparator4, "ToolStripSeparator4")
    '
    'ZagrozeniaToolStripMenuItem
    '
    resources.ApplyResources(Me.ZagrozeniaToolStripMenuItem, "ZagrozeniaToolStripMenuItem")
    Me.ZagrozeniaToolStripMenuItem.Name = "ZagrozeniaToolStripMenuItem"
    '
    'OsiagnieciaToolStripMenuItem
    '
    resources.ApplyResources(Me.OsiagnieciaToolStripMenuItem, "OsiagnieciaToolStripMenuItem")
    Me.OsiagnieciaToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.Trophy_Gold_48
    Me.OsiagnieciaToolStripMenuItem.Name = "OsiagnieciaToolStripMenuItem"
    '
    'ToolStripSeparator6
    '
    Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
    resources.ApplyResources(Me.ToolStripSeparator6, "ToolStripSeparator6")
    '
    'ProjektyToolStripMenuItem
    '
    Me.ProjektyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentProjektToolStripMenuItem, Me.TematProjektToolStripMenuItem})
    resources.ApplyResources(Me.ProjektyToolStripMenuItem, "ProjektyToolStripMenuItem")
    Me.ProjektyToolStripMenuItem.Name = "ProjektyToolStripMenuItem"
    '
    'StudentProjektToolStripMenuItem
    '
    Me.StudentProjektToolStripMenuItem.Name = "StudentProjektToolStripMenuItem"
    resources.ApplyResources(Me.StudentProjektToolStripMenuItem, "StudentProjektToolStripMenuItem")
    '
    'TematProjektToolStripMenuItem
    '
    Me.TematProjektToolStripMenuItem.Name = "TematProjektToolStripMenuItem"
    resources.ApplyResources(Me.TematProjektToolStripMenuItem, "TematProjektToolStripMenuItem")
    '
    'ToolStripSeparator21
    '
    Me.ToolStripSeparator21.Name = "ToolStripSeparator21"
    resources.ApplyResources(Me.ToolStripSeparator21, "ToolStripSeparator21")
    '
    'PlanLekcjiToolStripMenuItem
    '
    resources.ApplyResources(Me.PlanLekcjiToolStripMenuItem, "PlanLekcjiToolStripMenuItem")
    Me.PlanLekcjiToolStripMenuItem.Name = "PlanLekcjiToolStripMenuItem"
    '
    'TerminarzToolStripMenuItem
    '
    resources.ApplyResources(Me.TerminarzToolStripMenuItem, "TerminarzToolStripMenuItem")
    Me.TerminarzToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.kalendarz
    Me.TerminarzToolStripMenuItem.Name = "TerminarzToolStripMenuItem"
    '
    'StatystykiToolStripMenuItem
    '
    Me.StatystykiToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LiczbaGodzinToolStripMenuItem, Me.ToolStripSeparator33, Me.AnalizaOcenToolStripMenuItem, Me.TableSetToolStripMenuItem, Me.KlasyfikacjaToolStripMenuItem, Me.ToolStripSeparator40, Me.WykazNdstToolStripMenuItem, Me.WykazNdpToolStripMenuItem, Me.ToolStripSeparator32, Me.NauczanieIndywidualneToolStripMenuItem, Me.ToolStripSeparator34, Me.AbsencjaByMonthToolStripMenuItem, Me.FrekwencjaToolStripMenuItem, Me.ReklamacjaToolStripMenuItem, Me.ToolStripSeparator36, Me.ParentLoggingToolStripMenuItem})
    resources.ApplyResources(Me.StatystykiToolStripMenuItem, "StatystykiToolStripMenuItem")
    Me.StatystykiToolStripMenuItem.Name = "StatystykiToolStripMenuItem"
    '
    'LiczbaGodzinToolStripMenuItem
    '
    Me.LiczbaGodzinToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LiczbaGodzinWgKlasToolStripMenuItem, Me.LiczbaGodzinWgNauczycielaToolStripMenuItem})
    Me.LiczbaGodzinToolStripMenuItem.Name = "LiczbaGodzinToolStripMenuItem"
    resources.ApplyResources(Me.LiczbaGodzinToolStripMenuItem, "LiczbaGodzinToolStripMenuItem")
    '
    'LiczbaGodzinWgKlasToolStripMenuItem
    '
    Me.LiczbaGodzinWgKlasToolStripMenuItem.Name = "LiczbaGodzinWgKlasToolStripMenuItem"
    resources.ApplyResources(Me.LiczbaGodzinWgKlasToolStripMenuItem, "LiczbaGodzinWgKlasToolStripMenuItem")
    '
    'LiczbaGodzinWgNauczycielaToolStripMenuItem
    '
    Me.LiczbaGodzinWgNauczycielaToolStripMenuItem.Name = "LiczbaGodzinWgNauczycielaToolStripMenuItem"
    resources.ApplyResources(Me.LiczbaGodzinWgNauczycielaToolStripMenuItem, "LiczbaGodzinWgNauczycielaToolStripMenuItem")
    '
    'ToolStripSeparator33
    '
    Me.ToolStripSeparator33.Name = "ToolStripSeparator33"
    resources.ApplyResources(Me.ToolStripSeparator33, "ToolStripSeparator33")
    '
    'AnalizaOcenToolStripMenuItem
    '
    Me.AnalizaOcenToolStripMenuItem.Name = "AnalizaOcenToolStripMenuItem"
    resources.ApplyResources(Me.AnalizaOcenToolStripMenuItem, "AnalizaOcenToolStripMenuItem")
    '
    'TableSetToolStripMenuItem
    '
    Me.TableSetToolStripMenuItem.Name = "TableSetToolStripMenuItem"
    resources.ApplyResources(Me.TableSetToolStripMenuItem, "TableSetToolStripMenuItem")
    '
    'KlasyfikacjaToolStripMenuItem
    '
    Me.KlasyfikacjaToolStripMenuItem.Name = "KlasyfikacjaToolStripMenuItem"
    resources.ApplyResources(Me.KlasyfikacjaToolStripMenuItem, "KlasyfikacjaToolStripMenuItem")
    '
    'ToolStripSeparator40
    '
    Me.ToolStripSeparator40.Name = "ToolStripSeparator40"
    resources.ApplyResources(Me.ToolStripSeparator40, "ToolStripSeparator40")
    '
    'WykazNdstToolStripMenuItem
    '
    Me.WykazNdstToolStripMenuItem.Name = "WykazNdstToolStripMenuItem"
    resources.ApplyResources(Me.WykazNdstToolStripMenuItem, "WykazNdstToolStripMenuItem")
    '
    'WykazNdpToolStripMenuItem
    '
    Me.WykazNdpToolStripMenuItem.Name = "WykazNdpToolStripMenuItem"
    resources.ApplyResources(Me.WykazNdpToolStripMenuItem, "WykazNdpToolStripMenuItem")
    '
    'ToolStripSeparator32
    '
    Me.ToolStripSeparator32.Name = "ToolStripSeparator32"
    resources.ApplyResources(Me.ToolStripSeparator32, "ToolStripSeparator32")
    '
    'NauczanieIndywidualneToolStripMenuItem
    '
    Me.NauczanieIndywidualneToolStripMenuItem.Name = "NauczanieIndywidualneToolStripMenuItem"
    resources.ApplyResources(Me.NauczanieIndywidualneToolStripMenuItem, "NauczanieIndywidualneToolStripMenuItem")
    '
    'ToolStripSeparator34
    '
    Me.ToolStripSeparator34.Name = "ToolStripSeparator34"
    resources.ApplyResources(Me.ToolStripSeparator34, "ToolStripSeparator34")
    '
    'AbsencjaByMonthToolStripMenuItem
    '
    Me.AbsencjaByMonthToolStripMenuItem.Name = "AbsencjaByMonthToolStripMenuItem"
    resources.ApplyResources(Me.AbsencjaByMonthToolStripMenuItem, "AbsencjaByMonthToolStripMenuItem")
    '
    'FrekwencjaToolStripMenuItem
    '
    Me.FrekwencjaToolStripMenuItem.Name = "FrekwencjaToolStripMenuItem"
    resources.ApplyResources(Me.FrekwencjaToolStripMenuItem, "FrekwencjaToolStripMenuItem")
    '
    'ReklamacjaToolStripMenuItem
    '
    Me.ReklamacjaToolStripMenuItem.Name = "ReklamacjaToolStripMenuItem"
    resources.ApplyResources(Me.ReklamacjaToolStripMenuItem, "ReklamacjaToolStripMenuItem")
    '
    'ToolStripSeparator36
    '
    Me.ToolStripSeparator36.Name = "ToolStripSeparator36"
    resources.ApplyResources(Me.ToolStripSeparator36, "ToolStripSeparator36")
    '
    'ParentLoggingToolStripMenuItem
    '
    Me.ParentLoggingToolStripMenuItem.Name = "ParentLoggingToolStripMenuItem"
    resources.ApplyResources(Me.ParentLoggingToolStripMenuItem, "ParentLoggingToolStripMenuItem")
    '
    'RaportyToolStripMenuItem
    '
    Me.RaportyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListaUczniowToolStripMenuItem, Me.ToolStripSeparator5, Me.WynikiToolStripMenuItem, Me.ZagrozeniaRaportToolStripMenuItem, Me.ToolStripSeparator11, Me.AbsencjaRaportToolStripMenuItem, Me.UwagiRaportToolStripMenuItem, Me.ToolStripSeparator14, Me.SwiadectwaToolStripMenuItem})
    resources.ApplyResources(Me.RaportyToolStripMenuItem, "RaportyToolStripMenuItem")
    Me.RaportyToolStripMenuItem.Name = "RaportyToolStripMenuItem"
    '
    'ListaUczniowToolStripMenuItem
    '
    Me.ListaUczniowToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.students
    Me.ListaUczniowToolStripMenuItem.Name = "ListaUczniowToolStripMenuItem"
    resources.ApplyResources(Me.ListaUczniowToolStripMenuItem, "ListaUczniowToolStripMenuItem")
    '
    'ToolStripSeparator5
    '
    Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
    resources.ApplyResources(Me.ToolStripSeparator5, "ToolStripSeparator5")
    '
    'WynikiToolStripMenuItem
    '
    Me.WynikiToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.ListaOcen
    Me.WynikiToolStripMenuItem.Name = "WynikiToolStripMenuItem"
    resources.ApplyResources(Me.WynikiToolStripMenuItem, "WynikiToolStripMenuItem")
    '
    'ZagrozeniaRaportToolStripMenuItem
    '
    resources.ApplyResources(Me.ZagrozeniaRaportToolStripMenuItem, "ZagrozeniaRaportToolStripMenuItem")
    Me.ZagrozeniaRaportToolStripMenuItem.Name = "ZagrozeniaRaportToolStripMenuItem"
    '
    'ToolStripSeparator11
    '
    Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
    resources.ApplyResources(Me.ToolStripSeparator11, "ToolStripSeparator11")
    '
    'AbsencjaRaportToolStripMenuItem
    '
    Me.AbsencjaRaportToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.frekwencja_48
    Me.AbsencjaRaportToolStripMenuItem.Name = "AbsencjaRaportToolStripMenuItem"
    resources.ApplyResources(Me.AbsencjaRaportToolStripMenuItem, "AbsencjaRaportToolStripMenuItem")
    '
    'UwagiRaportToolStripMenuItem
    '
    resources.ApplyResources(Me.UwagiRaportToolStripMenuItem, "UwagiRaportToolStripMenuItem")
    Me.UwagiRaportToolStripMenuItem.Name = "UwagiRaportToolStripMenuItem"
    '
    'ToolStripSeparator14
    '
    Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
    resources.ApplyResources(Me.ToolStripSeparator14, "ToolStripSeparator14")
    '
    'SwiadectwaToolStripMenuItem
    '
    resources.ApplyResources(Me.SwiadectwaToolStripMenuItem, "SwiadectwaToolStripMenuItem")
    Me.SwiadectwaToolStripMenuItem.Name = "SwiadectwaToolStripMenuItem"
    '
    'UstawieniaToolStripMenuItem
    '
    Me.UstawieniaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.KonfiguracjaToolStripMenuItem, Me.ZmianahasłaToolStripMenuItem, Me.ToolStripSeparator1, Me.SzkolyToolStripMenuItem, Me.PrzydzialToolStripMenuItem, Me.ObsadaToolStripMenuItem, Me.ToolStripSeparator13, Me.SlownikToolStripMenuItem, Me.KolumnyToolStripMenuItem, Me.ToolStripSeparator15, Me.UstawieniaSwiadectwToolStripMenuItem, Me.ToolStripSeparator29, Me.KalibracjaWydrukuToolStripMenuItem})
    resources.ApplyResources(Me.UstawieniaToolStripMenuItem, "UstawieniaToolStripMenuItem")
    Me.UstawieniaToolStripMenuItem.Name = "UstawieniaToolStripMenuItem"
    '
    'KonfiguracjaToolStripMenuItem
    '
    resources.ApplyResources(Me.KonfiguracjaToolStripMenuItem, "KonfiguracjaToolStripMenuItem")
    Me.KonfiguracjaToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.run_48
    Me.KonfiguracjaToolStripMenuItem.Name = "KonfiguracjaToolStripMenuItem"
    '
    'ZmianahasłaToolStripMenuItem
    '
    resources.ApplyResources(Me.ZmianahasłaToolStripMenuItem, "ZmianahasłaToolStripMenuItem")
    Me.ZmianahasłaToolStripMenuItem.Name = "ZmianahasłaToolStripMenuItem"
    '
    'ToolStripSeparator1
    '
    Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
    resources.ApplyResources(Me.ToolStripSeparator1, "ToolStripSeparator1")
    '
    'SzkolyToolStripMenuItem
    '
    resources.ApplyResources(Me.SzkolyToolStripMenuItem, "SzkolyToolStripMenuItem")
    Me.SzkolyToolStripMenuItem.Name = "SzkolyToolStripMenuItem"
    '
    'PrzydzialToolStripMenuItem
    '
    Me.PrzydzialToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrzydzialKlasDoSzkolToolStripMenuItem, Me.PrzydzialPrzedmiotowDoSzkolToolStripMenuItem, Me.PrzydzialNauczycieliDoSzkolToolStripMenuItem, Me.PrzydzialWychowawstwToolStripMenuItem})
    resources.ApplyResources(Me.PrzydzialToolStripMenuItem, "PrzydzialToolStripMenuItem")
    Me.PrzydzialToolStripMenuItem.Name = "PrzydzialToolStripMenuItem"
    '
    'PrzydzialKlasDoSzkolToolStripMenuItem
    '
    Me.PrzydzialKlasDoSzkolToolStripMenuItem.Name = "PrzydzialKlasDoSzkolToolStripMenuItem"
    resources.ApplyResources(Me.PrzydzialKlasDoSzkolToolStripMenuItem, "PrzydzialKlasDoSzkolToolStripMenuItem")
    '
    'PrzydzialPrzedmiotowDoSzkolToolStripMenuItem
    '
    Me.PrzydzialPrzedmiotowDoSzkolToolStripMenuItem.Name = "PrzydzialPrzedmiotowDoSzkolToolStripMenuItem"
    resources.ApplyResources(Me.PrzydzialPrzedmiotowDoSzkolToolStripMenuItem, "PrzydzialPrzedmiotowDoSzkolToolStripMenuItem")
    '
    'PrzydzialNauczycieliDoSzkolToolStripMenuItem
    '
    Me.PrzydzialNauczycieliDoSzkolToolStripMenuItem.Name = "PrzydzialNauczycieliDoSzkolToolStripMenuItem"
    resources.ApplyResources(Me.PrzydzialNauczycieliDoSzkolToolStripMenuItem, "PrzydzialNauczycieliDoSzkolToolStripMenuItem")
    '
    'PrzydzialWychowawstwToolStripMenuItem
    '
    Me.PrzydzialWychowawstwToolStripMenuItem.Name = "PrzydzialWychowawstwToolStripMenuItem"
    resources.ApplyResources(Me.PrzydzialWychowawstwToolStripMenuItem, "PrzydzialWychowawstwToolStripMenuItem")
    '
    'ObsadaToolStripMenuItem
    '
    resources.ApplyResources(Me.ObsadaToolStripMenuItem, "ObsadaToolStripMenuItem")
    Me.ObsadaToolStripMenuItem.Name = "ObsadaToolStripMenuItem"
    '
    'ToolStripSeparator13
    '
    Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
    resources.ApplyResources(Me.ToolStripSeparator13, "ToolStripSeparator13")
    '
    'SlownikToolStripMenuItem
    '
    Me.SlownikToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MiejscowoscToolStripMenuItem, Me.WojewodztwaToolStripMenuItem, Me.KrajeToolStripMenuItem, Me.ToolStripSeparator3, Me.TypySzkolToolStripMenuItem, Me.OddzialyToolStripMenuItem, Me.PrzedmiotyToolStripMenuItem, Me.ToolStripSeparator9, Me.NauczycieleToolStripMenuItem, Me.ToolStripSeparator20, Me.SkalaOcenToolStripMenuItem, Me.OpisyOcenToolStripMenuItem, Me.HarmonogramToolStripMenuItem})
    resources.ApplyResources(Me.SlownikToolStripMenuItem, "SlownikToolStripMenuItem")
    Me.SlownikToolStripMenuItem.Name = "SlownikToolStripMenuItem"
    '
    'MiejscowoscToolStripMenuItem
    '
    resources.ApplyResources(Me.MiejscowoscToolStripMenuItem, "MiejscowoscToolStripMenuItem")
    Me.MiejscowoscToolStripMenuItem.Name = "MiejscowoscToolStripMenuItem"
    '
    'WojewodztwaToolStripMenuItem
    '
    resources.ApplyResources(Me.WojewodztwaToolStripMenuItem, "WojewodztwaToolStripMenuItem")
    Me.WojewodztwaToolStripMenuItem.Name = "WojewodztwaToolStripMenuItem"
    '
    'KrajeToolStripMenuItem
    '
    resources.ApplyResources(Me.KrajeToolStripMenuItem, "KrajeToolStripMenuItem")
    Me.KrajeToolStripMenuItem.Name = "KrajeToolStripMenuItem"
    '
    'ToolStripSeparator3
    '
    Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
    resources.ApplyResources(Me.ToolStripSeparator3, "ToolStripSeparator3")
    '
    'TypySzkolToolStripMenuItem
    '
    resources.ApplyResources(Me.TypySzkolToolStripMenuItem, "TypySzkolToolStripMenuItem")
    Me.TypySzkolToolStripMenuItem.Name = "TypySzkolToolStripMenuItem"
    '
    'OddzialyToolStripMenuItem
    '
    resources.ApplyResources(Me.OddzialyToolStripMenuItem, "OddzialyToolStripMenuItem")
    Me.OddzialyToolStripMenuItem.Name = "OddzialyToolStripMenuItem"
    '
    'PrzedmiotyToolStripMenuItem
    '
    resources.ApplyResources(Me.PrzedmiotyToolStripMenuItem, "PrzedmiotyToolStripMenuItem")
    Me.PrzedmiotyToolStripMenuItem.Name = "PrzedmiotyToolStripMenuItem"
    '
    'ToolStripSeparator9
    '
    Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
    resources.ApplyResources(Me.ToolStripSeparator9, "ToolStripSeparator9")
    '
    'NauczycieleToolStripMenuItem
    '
    resources.ApplyResources(Me.NauczycieleToolStripMenuItem, "NauczycieleToolStripMenuItem")
    Me.NauczycieleToolStripMenuItem.Name = "NauczycieleToolStripMenuItem"
    '
    'ToolStripSeparator20
    '
    Me.ToolStripSeparator20.Name = "ToolStripSeparator20"
    resources.ApplyResources(Me.ToolStripSeparator20, "ToolStripSeparator20")
    '
    'SkalaOcenToolStripMenuItem
    '
    resources.ApplyResources(Me.SkalaOcenToolStripMenuItem, "SkalaOcenToolStripMenuItem")
    Me.SkalaOcenToolStripMenuItem.Name = "SkalaOcenToolStripMenuItem"
    '
    'OpisyOcenToolStripMenuItem
    '
    resources.ApplyResources(Me.OpisyOcenToolStripMenuItem, "OpisyOcenToolStripMenuItem")
    Me.OpisyOcenToolStripMenuItem.Name = "OpisyOcenToolStripMenuItem"
    '
    'HarmonogramToolStripMenuItem
    '
    resources.ApplyResources(Me.HarmonogramToolStripMenuItem, "HarmonogramToolStripMenuItem")
    Me.HarmonogramToolStripMenuItem.Name = "HarmonogramToolStripMenuItem"
    '
    'KolumnyToolStripMenuItem
    '
    resources.ApplyResources(Me.KolumnyToolStripMenuItem, "KolumnyToolStripMenuItem")
    Me.KolumnyToolStripMenuItem.Name = "KolumnyToolStripMenuItem"
    '
    'ToolStripSeparator15
    '
    Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
    resources.ApplyResources(Me.ToolStripSeparator15, "ToolStripSeparator15")
    '
    'UstawieniaSwiadectwToolStripMenuItem
    '
    Me.UstawieniaSwiadectwToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PierwszaStronaSwiadectwaToolStripMenuItem, Me.KryteriaPasekToolStripMenuItem, Me.ToolStripSeparator16, Me.CzcionkiToolStripMenuItem, Me.KalibracjaWydrukuSwiadectwToolStripMenuItem, Me.ToolStripSeparator17, Me.SzablonyToolStripMenuItem, Me.OpcjeSwiadectwaToolStripMenuItem})
    resources.ApplyResources(Me.UstawieniaSwiadectwToolStripMenuItem, "UstawieniaSwiadectwToolStripMenuItem")
    Me.UstawieniaSwiadectwToolStripMenuItem.Name = "UstawieniaSwiadectwToolStripMenuItem"
    '
    'PierwszaStronaSwiadectwaToolStripMenuItem
    '
    Me.PierwszaStronaSwiadectwaToolStripMenuItem.Name = "PierwszaStronaSwiadectwaToolStripMenuItem"
    resources.ApplyResources(Me.PierwszaStronaSwiadectwaToolStripMenuItem, "PierwszaStronaSwiadectwaToolStripMenuItem")
    '
    'KryteriaPasekToolStripMenuItem
    '
    Me.KryteriaPasekToolStripMenuItem.Name = "KryteriaPasekToolStripMenuItem"
    resources.ApplyResources(Me.KryteriaPasekToolStripMenuItem, "KryteriaPasekToolStripMenuItem")
    '
    'ToolStripSeparator16
    '
    Me.ToolStripSeparator16.Name = "ToolStripSeparator16"
    resources.ApplyResources(Me.ToolStripSeparator16, "ToolStripSeparator16")
    '
    'CzcionkiToolStripMenuItem
    '
    Me.CzcionkiToolStripMenuItem.Name = "CzcionkiToolStripMenuItem"
    resources.ApplyResources(Me.CzcionkiToolStripMenuItem, "CzcionkiToolStripMenuItem")
    '
    'KalibracjaWydrukuSwiadectwToolStripMenuItem
    '
    Me.KalibracjaWydrukuSwiadectwToolStripMenuItem.Name = "KalibracjaWydrukuSwiadectwToolStripMenuItem"
    resources.ApplyResources(Me.KalibracjaWydrukuSwiadectwToolStripMenuItem, "KalibracjaWydrukuSwiadectwToolStripMenuItem")
    '
    'ToolStripSeparator17
    '
    Me.ToolStripSeparator17.Name = "ToolStripSeparator17"
    resources.ApplyResources(Me.ToolStripSeparator17, "ToolStripSeparator17")
    '
    'SzablonyToolStripMenuItem
    '
    Me.SzablonyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SymboleSwiadectwToolStripMenuItem, Me.DefinicjeSzablonowToolStripMenuItem, Me.PowiazwaniaSzablonowToolStripMenuItem, Me.ToolStripSeparator18, Me.ImportSzablonuToolStripMenuItem, Me.ExportSzablonuToolStripMenuItem, Me.ToolStripSeparator19, Me.KalkulatorTekstuToolStripMenuItem})
    Me.SzablonyToolStripMenuItem.Name = "SzablonyToolStripMenuItem"
    resources.ApplyResources(Me.SzablonyToolStripMenuItem, "SzablonyToolStripMenuItem")
    '
    'SymboleSwiadectwToolStripMenuItem
    '
    Me.SymboleSwiadectwToolStripMenuItem.Name = "SymboleSwiadectwToolStripMenuItem"
    resources.ApplyResources(Me.SymboleSwiadectwToolStripMenuItem, "SymboleSwiadectwToolStripMenuItem")
    '
    'DefinicjeSzablonowToolStripMenuItem
    '
    Me.DefinicjeSzablonowToolStripMenuItem.Name = "DefinicjeSzablonowToolStripMenuItem"
    resources.ApplyResources(Me.DefinicjeSzablonowToolStripMenuItem, "DefinicjeSzablonowToolStripMenuItem")
    '
    'PowiazwaniaSzablonowToolStripMenuItem
    '
    Me.PowiazwaniaSzablonowToolStripMenuItem.Name = "PowiazwaniaSzablonowToolStripMenuItem"
    resources.ApplyResources(Me.PowiazwaniaSzablonowToolStripMenuItem, "PowiazwaniaSzablonowToolStripMenuItem")
    '
    'ToolStripSeparator18
    '
    Me.ToolStripSeparator18.Name = "ToolStripSeparator18"
    resources.ApplyResources(Me.ToolStripSeparator18, "ToolStripSeparator18")
    '
    'ImportSzablonuToolStripMenuItem
    '
    Me.ImportSzablonuToolStripMenuItem.Name = "ImportSzablonuToolStripMenuItem"
    resources.ApplyResources(Me.ImportSzablonuToolStripMenuItem, "ImportSzablonuToolStripMenuItem")
    '
    'ExportSzablonuToolStripMenuItem
    '
    Me.ExportSzablonuToolStripMenuItem.Name = "ExportSzablonuToolStripMenuItem"
    resources.ApplyResources(Me.ExportSzablonuToolStripMenuItem, "ExportSzablonuToolStripMenuItem")
    '
    'ToolStripSeparator19
    '
    Me.ToolStripSeparator19.Name = "ToolStripSeparator19"
    resources.ApplyResources(Me.ToolStripSeparator19, "ToolStripSeparator19")
    '
    'KalkulatorTekstuToolStripMenuItem
    '
    resources.ApplyResources(Me.KalkulatorTekstuToolStripMenuItem, "KalkulatorTekstuToolStripMenuItem")
    Me.KalkulatorTekstuToolStripMenuItem.Name = "KalkulatorTekstuToolStripMenuItem"
    '
    'OpcjeSwiadectwaToolStripMenuItem
    '
    Me.OpcjeSwiadectwaToolStripMenuItem.Name = "OpcjeSwiadectwaToolStripMenuItem"
    resources.ApplyResources(Me.OpcjeSwiadectwaToolStripMenuItem, "OpcjeSwiadectwaToolStripMenuItem")
    '
    'ToolStripSeparator29
    '
    Me.ToolStripSeparator29.Name = "ToolStripSeparator29"
    resources.ApplyResources(Me.ToolStripSeparator29, "ToolStripSeparator29")
    '
    'KalibracjaWydrukuToolStripMenuItem
    '
    Me.KalibracjaWydrukuToolStripMenuItem.Name = "KalibracjaWydrukuToolStripMenuItem"
    resources.ApplyResources(Me.KalibracjaWydrukuToolStripMenuItem, "KalibracjaWydrukuToolStripMenuItem")
    '
    'NadzorToolStripMenuItem
    '
    Me.NadzorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ZastepstwoToolStripMenuItem, Me.ManagePlanLekcjiToolStripMenuItem, Me.MinLekcjaToolStripMenuItem, Me.ToolStripSeparator39, Me.ZestawienieKlasyfikacjiToolStripMenuItem, Me.UzasadnieniaToolStripMenuItem, Me.ToolStripSeparator30, Me.UserActivityToolStripMenuItem})
    resources.ApplyResources(Me.NadzorToolStripMenuItem, "NadzorToolStripMenuItem")
    Me.NadzorToolStripMenuItem.Name = "NadzorToolStripMenuItem"
    '
    'ZastepstwoToolStripMenuItem
    '
    resources.ApplyResources(Me.ZastepstwoToolStripMenuItem, "ZastepstwoToolStripMenuItem")
    Me.ZastepstwoToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.zastepstwo
    Me.ZastepstwoToolStripMenuItem.Name = "ZastepstwoToolStripMenuItem"
    '
    'ManagePlanLekcjiToolStripMenuItem
    '
    resources.ApplyResources(Me.ManagePlanLekcjiToolStripMenuItem, "ManagePlanLekcjiToolStripMenuItem")
    Me.ManagePlanLekcjiToolStripMenuItem.Image = Global.belfer.NET.My.Resources.Resources.timetable
    Me.ManagePlanLekcjiToolStripMenuItem.Name = "ManagePlanLekcjiToolStripMenuItem"
    '
    'MinLekcjaToolStripMenuItem
    '
    resources.ApplyResources(Me.MinLekcjaToolStripMenuItem, "MinLekcjaToolStripMenuItem")
    Me.MinLekcjaToolStripMenuItem.Name = "MinLekcjaToolStripMenuItem"
    '
    'ToolStripSeparator39
    '
    Me.ToolStripSeparator39.Name = "ToolStripSeparator39"
    resources.ApplyResources(Me.ToolStripSeparator39, "ToolStripSeparator39")
    '
    'ZestawienieKlasyfikacjiToolStripMenuItem
    '
    resources.ApplyResources(Me.ZestawienieKlasyfikacjiToolStripMenuItem, "ZestawienieKlasyfikacjiToolStripMenuItem")
    Me.ZestawienieKlasyfikacjiToolStripMenuItem.Name = "ZestawienieKlasyfikacjiToolStripMenuItem"
    '
    'UzasadnieniaToolStripMenuItem
    '
    resources.ApplyResources(Me.UzasadnieniaToolStripMenuItem, "UzasadnieniaToolStripMenuItem")
    Me.UzasadnieniaToolStripMenuItem.Name = "UzasadnieniaToolStripMenuItem"
    '
    'ToolStripSeparator30
    '
    Me.ToolStripSeparator30.Name = "ToolStripSeparator30"
    resources.ApplyResources(Me.ToolStripSeparator30, "ToolStripSeparator30")
    '
    'UserActivityToolStripMenuItem
    '
    resources.ApplyResources(Me.UserActivityToolStripMenuItem, "UserActivityToolStripMenuItem")
    Me.UserActivityToolStripMenuItem.Name = "UserActivityToolStripMenuItem"
    '
    'AdminToolStripMenuItem
    '
    Me.AdminToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApplicationToolStripMenuItem, Me.ToolStripSeparator35, Me.ZarzadzanieuzytkownikamiToolStripMenuItem, Me.ZmianaHasla2ToolStripMenuItem, Me.ToolStripSeparator37, Me.UprawnieniaToolStripMenuItem, Me.OutofdatePrivilageToolStripMenuItem, Me.ToolStripSeparator2, Me.LoggingToolStripMenuItem, Me.CurrentConnectionToolStripMenuItem, Me.ToolStripSeparator38, Me.ServiceToolStripMenuItem})
    resources.ApplyResources(Me.AdminToolStripMenuItem, "AdminToolStripMenuItem")
    Me.AdminToolStripMenuItem.Name = "AdminToolStripMenuItem"
    '
    'ApplicationToolStripMenuItem
    '
    Me.ApplicationToolStripMenuItem.Name = "ApplicationToolStripMenuItem"
    resources.ApplyResources(Me.ApplicationToolStripMenuItem, "ApplicationToolStripMenuItem")
    '
    'ToolStripSeparator35
    '
    Me.ToolStripSeparator35.Name = "ToolStripSeparator35"
    resources.ApplyResources(Me.ToolStripSeparator35, "ToolStripSeparator35")
    '
    'ZarzadzanieuzytkownikamiToolStripMenuItem
    '
    Me.ZarzadzanieuzytkownikamiToolStripMenuItem.Name = "ZarzadzanieuzytkownikamiToolStripMenuItem"
    resources.ApplyResources(Me.ZarzadzanieuzytkownikamiToolStripMenuItem, "ZarzadzanieuzytkownikamiToolStripMenuItem")
    '
    'ZmianaHasla2ToolStripMenuItem
    '
    Me.ZmianaHasla2ToolStripMenuItem.Name = "ZmianaHasla2ToolStripMenuItem"
    resources.ApplyResources(Me.ZmianaHasla2ToolStripMenuItem, "ZmianaHasla2ToolStripMenuItem")
    '
    'ToolStripSeparator37
    '
    Me.ToolStripSeparator37.Name = "ToolStripSeparator37"
    resources.ApplyResources(Me.ToolStripSeparator37, "ToolStripSeparator37")
    '
    'UprawnieniaToolStripMenuItem
    '
    Me.UprawnieniaToolStripMenuItem.Name = "UprawnieniaToolStripMenuItem"
    resources.ApplyResources(Me.UprawnieniaToolStripMenuItem, "UprawnieniaToolStripMenuItem")
    '
    'OutofdatePrivilageToolStripMenuItem
    '
    Me.OutofdatePrivilageToolStripMenuItem.Name = "OutofdatePrivilageToolStripMenuItem"
    resources.ApplyResources(Me.OutofdatePrivilageToolStripMenuItem, "OutofdatePrivilageToolStripMenuItem")
    '
    'ToolStripSeparator2
    '
    Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
    resources.ApplyResources(Me.ToolStripSeparator2, "ToolStripSeparator2")
    '
    'LoggingToolStripMenuItem
    '
    Me.LoggingToolStripMenuItem.Name = "LoggingToolStripMenuItem"
    resources.ApplyResources(Me.LoggingToolStripMenuItem, "LoggingToolStripMenuItem")
    '
    'CurrentConnectionToolStripMenuItem
    '
    Me.CurrentConnectionToolStripMenuItem.Name = "CurrentConnectionToolStripMenuItem"
    resources.ApplyResources(Me.CurrentConnectionToolStripMenuItem, "CurrentConnectionToolStripMenuItem")
    '
    'ToolStripSeparator38
    '
    Me.ToolStripSeparator38.Name = "ToolStripSeparator38"
    resources.ApplyResources(Me.ToolStripSeparator38, "ToolStripSeparator38")
    '
    'ServiceToolStripMenuItem
    '
    Me.ServiceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MoveResultToolStripMenuItem, Me.LockResultColumnToolStripMenuItem, Me.SQLToolStripMenuItem})
    Me.ServiceToolStripMenuItem.Name = "ServiceToolStripMenuItem"
    resources.ApplyResources(Me.ServiceToolStripMenuItem, "ServiceToolStripMenuItem")
    '
    'MoveResultToolStripMenuItem
    '
    Me.MoveResultToolStripMenuItem.Name = "MoveResultToolStripMenuItem"
    resources.ApplyResources(Me.MoveResultToolStripMenuItem, "MoveResultToolStripMenuItem")
    '
    'LockResultColumnToolStripMenuItem
    '
    Me.LockResultColumnToolStripMenuItem.Name = "LockResultColumnToolStripMenuItem"
    resources.ApplyResources(Me.LockResultColumnToolStripMenuItem, "LockResultColumnToolStripMenuItem")
    '
    'SQLToolStripMenuItem
    '
    Me.SQLToolStripMenuItem.Name = "SQLToolStripMenuItem"
    resources.ApplyResources(Me.SQLToolStripMenuItem, "SQLToolStripMenuItem")
    '
    'ProgramToolStripMenuItem
    '
    resources.ApplyResources(Me.ProgramToolStripMenuItem, "ProgramToolStripMenuItem")
    Me.ProgramToolStripMenuItem.Name = "ProgramToolStripMenuItem"
    '
    'tblStatus
    '
    resources.ApplyResources(Me.tblStatus, "tblStatus")
    Me.tblStatus.Controls.Add(Me.MainStatus, 0, 0)
    Me.tblStatus.Controls.Add(Me.SubStatus, 1, 0)
    Me.tblStatus.Name = "tblStatus"
    '
    'MainStatus
    '
    Me.MainStatus.BackColor = System.Drawing.SystemColors.Control
    Me.MainStatus.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.statSSLMode, Me.ToolStripStatusLabel1, Me.StatConn, Me.ToolStripStatusLabel2, Me.StatUser, Me.ToolStripStatusLabel3, Me.statRole})
    resources.ApplyResources(Me.MainStatus, "MainStatus")
    Me.MainStatus.Name = "MainStatus"
    Me.MainStatus.ShowItemToolTips = True
    '
    'statSSLMode
    '
    resources.ApplyResources(Me.statSSLMode, "statSSLMode")
    Me.statSSLMode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
    Me.statSSLMode.Image = Global.belfer.NET.My.Resources.Resources.unlock
    Me.statSSLMode.Name = "statSSLMode"
    '
    'ToolStripStatusLabel1
    '
    Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
    resources.ApplyResources(Me.ToolStripStatusLabel1, "ToolStripStatusLabel1")
    '
    'StatConn
    '
    resources.ApplyResources(Me.StatConn, "StatConn")
    Me.StatConn.ForeColor = System.Drawing.Color.Firebrick
    Me.StatConn.Name = "StatConn"
    Me.StatConn.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal
    '
    'ToolStripStatusLabel2
    '
    Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
    resources.ApplyResources(Me.ToolStripStatusLabel2, "ToolStripStatusLabel2")
    '
    'StatUser
    '
    resources.ApplyResources(Me.StatUser, "StatUser")
    Me.StatUser.ForeColor = System.Drawing.Color.Blue
    Me.StatUser.Name = "StatUser"
    '
    'ToolStripStatusLabel3
    '
    Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
    resources.ApplyResources(Me.ToolStripStatusLabel3, "ToolStripStatusLabel3")
    '
    'statRole
    '
    resources.ApplyResources(Me.statRole, "statRole")
    Me.statRole.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
    Me.statRole.Margin = New System.Windows.Forms.Padding(0, 3, 50, 2)
    Me.statRole.Name = "statRole"
    '
    'SubStatus
    '
    resources.ApplyResources(Me.SubStatus, "SubStatus")
    Me.SubStatus.BackColor = System.Drawing.SystemColors.Control
    Me.SubStatus.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel4, Me.statServer, Me.ToolStripStatusLabel5, Me.statBaza})
    Me.SubStatus.Name = "SubStatus"
    '
    'ToolStripStatusLabel4
    '
    Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
    resources.ApplyResources(Me.ToolStripStatusLabel4, "ToolStripStatusLabel4")
    '
    'statServer
    '
    resources.ApplyResources(Me.statServer, "statServer")
    Me.statServer.ForeColor = System.Drawing.Color.SteelBlue
    Me.statServer.Name = "statServer"
    '
    'ToolStripStatusLabel5
    '
    Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
    resources.ApplyResources(Me.ToolStripStatusLabel5, "ToolStripStatusLabel5")
    '
    'statBaza
    '
    resources.ApplyResources(Me.statBaza, "statBaza")
    Me.statBaza.ForeColor = System.Drawing.Color.SteelBlue
    Me.statBaza.Name = "statBaza"
    '
    'tlpCommonData
    '
    Me.tlpCommonData.BackColor = System.Drawing.SystemColors.InactiveBorder
    resources.ApplyResources(Me.tlpCommonData, "tlpCommonData")
    Me.tlpCommonData.Controls.Add(Me.Label1, 0, 0)
    Me.tlpCommonData.Controls.Add(Me.lblRokSzkolny, 1, 0)
    Me.tlpCommonData.Controls.Add(Me.Label3, 2, 0)
    Me.tlpCommonData.Controls.Add(Me.lblSchoolName, 3, 0)
    Me.tlpCommonData.Name = "tlpCommonData"
    '
    'Label1
    '
    resources.ApplyResources(Me.Label1, "Label1")
    Me.Label1.Name = "Label1"
    '
    'lblRokSzkolny
    '
    resources.ApplyResources(Me.lblRokSzkolny, "lblRokSzkolny")
    Me.lblRokSzkolny.ForeColor = System.Drawing.SystemColors.MenuHighlight
    Me.lblRokSzkolny.Name = "lblRokSzkolny"
    '
    'Label3
    '
    resources.ApplyResources(Me.Label3, "Label3")
    Me.Label3.Name = "Label3"
    '
    'lblSchoolName
    '
    resources.ApplyResources(Me.lblSchoolName, "lblSchoolName")
    Me.lblSchoolName.BackColor = System.Drawing.SystemColors.InactiveBorder
    Me.lblSchoolName.ForeColor = System.Drawing.SystemColors.MenuHighlight
    Me.lblSchoolName.Name = "lblSchoolName"
    '
    'ToolStripSeparator27
    '
    Me.ToolStripSeparator27.Name = "ToolStripSeparator27"
    resources.ApplyResources(Me.ToolStripSeparator27, "ToolStripSeparator27")
    '
    'ToolStripSeparator31
    '
    Me.ToolStripSeparator31.Name = "ToolStripSeparator31"
    resources.ApplyResources(Me.ToolStripSeparator31, "ToolStripSeparator31")
    '
    'ToolStripSeparator22
    '
    Me.ToolStripSeparator22.Name = "ToolStripSeparator22"
    resources.ApplyResources(Me.ToolStripSeparator22, "ToolStripSeparator22")
    '
    'ToolStripSeparator23
    '
    Me.ToolStripSeparator23.Name = "ToolStripSeparator23"
    resources.ApplyResources(Me.ToolStripSeparator23, "ToolStripSeparator23")
    '
    'ToolStripSeparator24
    '
    Me.ToolStripSeparator24.Name = "ToolStripSeparator24"
    resources.ApplyResources(Me.ToolStripSeparator24, "ToolStripSeparator24")
    '
    'ToolStripSeparator25
    '
    resources.ApplyResources(Me.ToolStripSeparator25, "ToolStripSeparator25")
    Me.ToolStripSeparator25.BackColor = System.Drawing.SystemColors.ActiveCaption
    Me.ToolStripSeparator25.Margin = New System.Windows.Forms.Padding(0, 0, 0, 100)
    Me.ToolStripSeparator25.Name = "ToolStripSeparator25"
    '
    'QuickAccessToolStrip
    '
    Me.QuickAccessToolStrip.CanOverflow = False
    resources.ApplyResources(Me.QuickAccessToolStrip, "QuickAccessToolStrip")
    Me.QuickAccessToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
    Me.QuickAccessToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cmdTerminarz, Me.cmdTemat, Me.cmdTematByNauczyciel, Me.ToolStripSeparator31, Me.cmdWynikiCzastkowe, Me.cmdOcenyZachowania, Me.ToolStripSeparator22, Me.cmdAbsencja, Me.ToolStripSeparator23, Me.cmdUwaga, Me.ToolStripSeparator24, Me.cmdZagrozenia, Me.ToolStripSeparator25, Me.KonfiguracjaToolStripButton, Me.cmdWyloguj, Me.cmdCloseProgram})
    Me.QuickAccessToolStrip.Name = "QuickAccessToolStrip"
    '
    'cmdTerminarz
    '
    Me.cmdTerminarz.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    resources.ApplyResources(Me.cmdTerminarz, "cmdTerminarz")
    Me.cmdTerminarz.Image = Global.belfer.NET.My.Resources.Resources.kalendarz
    Me.cmdTerminarz.Name = "cmdTerminarz"
    '
    'cmdTemat
    '
    Me.cmdTemat.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    resources.ApplyResources(Me.cmdTemat, "cmdTemat")
    Me.cmdTemat.Image = Global.belfer.NET.My.Resources.Resources.tematByData
    Me.cmdTemat.Name = "cmdTemat"
    '
    'cmdTematByNauczyciel
    '
    Me.cmdTematByNauczyciel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    resources.ApplyResources(Me.cmdTematByNauczyciel, "cmdTematByNauczyciel")
    Me.cmdTematByNauczyciel.Image = Global.belfer.NET.My.Resources.Resources.tematByBelfer
    Me.cmdTematByNauczyciel.Name = "cmdTematByNauczyciel"
    '
    'cmdWynikiCzastkowe
    '
    Me.cmdWynikiCzastkowe.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    resources.ApplyResources(Me.cmdWynikiCzastkowe, "cmdWynikiCzastkowe")
    Me.cmdWynikiCzastkowe.Name = "cmdWynikiCzastkowe"
    '
    'cmdOcenyZachowania
    '
    Me.cmdOcenyZachowania.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    resources.ApplyResources(Me.cmdOcenyZachowania, "cmdOcenyZachowania")
    Me.cmdOcenyZachowania.Image = Global.belfer.NET.My.Resources.Resources.zachowanie
    Me.cmdOcenyZachowania.Name = "cmdOcenyZachowania"
    '
    'cmdAbsencja
    '
    Me.cmdAbsencja.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    resources.ApplyResources(Me.cmdAbsencja, "cmdAbsencja")
    Me.cmdAbsencja.Image = Global.belfer.NET.My.Resources.Resources.frekwencja_48
    Me.cmdAbsencja.Name = "cmdAbsencja"
    '
    'cmdUwaga
    '
    Me.cmdUwaga.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    resources.ApplyResources(Me.cmdUwaga, "cmdUwaga")
    Me.cmdUwaga.Name = "cmdUwaga"
    '
    'cmdZagrozenia
    '
    Me.cmdZagrozenia.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    resources.ApplyResources(Me.cmdZagrozenia, "cmdZagrozenia")
    Me.cmdZagrozenia.Name = "cmdZagrozenia"
    '
    'KonfiguracjaToolStripButton
    '
    Me.KonfiguracjaToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    resources.ApplyResources(Me.KonfiguracjaToolStripButton, "KonfiguracjaToolStripButton")
    Me.KonfiguracjaToolStripButton.Image = Global.belfer.NET.My.Resources.Resources.run_48
    Me.KonfiguracjaToolStripButton.Margin = New System.Windows.Forms.Padding(0, 0, 0, 2)
    Me.KonfiguracjaToolStripButton.Name = "KonfiguracjaToolStripButton"
    '
    'cmdWyloguj
    '
    Me.cmdWyloguj.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.cmdWyloguj.Image = Global.belfer.NET.My.Resources.Resources.logoutuser_48
    resources.ApplyResources(Me.cmdWyloguj, "cmdWyloguj")
    Me.cmdWyloguj.Name = "cmdWyloguj"
    '
    'cmdCloseProgram
    '
    Me.cmdCloseProgram.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.cmdCloseProgram.Image = Global.belfer.NET.My.Resources.Resources.exit_48
    resources.ApplyResources(Me.cmdCloseProgram, "cmdCloseProgram")
    Me.cmdCloseProgram.Name = "cmdCloseProgram"
    '
    'MainForm
    '
    resources.ApplyResources(Me, "$this")
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.Controls.Add(Me.QuickAccessToolStrip)
    Me.Controls.Add(Me.tlpCommonData)
    Me.Controls.Add(Me.tblStatus)
    Me.Controls.Add(Me.MainMenuToolStrip)
    Me.IsMdiContainer = True
    Me.MainMenuStrip = Me.MainMenuToolStrip
    Me.Name = "MainForm"
    Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
    Me.MainMenuToolStrip.ResumeLayout(False)
    Me.MainMenuToolStrip.PerformLayout()
    Me.tblStatus.ResumeLayout(False)
    Me.tblStatus.PerformLayout()
    Me.MainStatus.ResumeLayout(False)
    Me.MainStatus.PerformLayout()
    Me.SubStatus.ResumeLayout(False)
    Me.SubStatus.PerformLayout()
    Me.tlpCommonData.ResumeLayout(False)
    Me.tlpCommonData.PerformLayout()
    Me.QuickAccessToolStrip.ResumeLayout(False)
    Me.QuickAccessToolStrip.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents MainMenuToolStrip As System.Windows.Forms.MenuStrip
  Friend WithEvents PlikToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents WylogujToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ZamknijToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents UstawieniaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ZmianahasłaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents tblStatus As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents MainStatus As System.Windows.Forms.StatusStrip
  Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents StatConn As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents StatUser As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents statRole As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents SubStatus As System.Windows.Forms.StatusStrip
  Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents statServer As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents ToolStripStatusLabel5 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents statBaza As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents SzkolyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents SlownikToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents MiejscowoscToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents WojewodztwaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents KrajeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents TypySzkolToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents OddzialyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PrzedmiotyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents NauczycieleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ImportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents UczniowieToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents DanePersonalneToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents PrzydzialUczniowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PromocjaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents DziennikToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents OcenyCzastkoweToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents OcenyZachowanieToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ZagrozeniaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents OsiagnieciaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents AbsencjaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents UwagiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ProjektyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents StatystykiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents RaportyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ListaUczniowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents WynikiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ZagrozeniaRaportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents AbsencjaRaportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents UwagiRaportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ProgramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PrzydzialToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PrzydzialKlasDoSzkolToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PrzydzialNauczycieliDoSzkolToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents SwiadectwaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator15 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents UstawieniaSwiadectwToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PierwszaStronaSwiadectwaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents KryteriaPasekToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator16 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents CzcionkiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents KalibracjaWydrukuSwiadectwToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator17 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents SzablonyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents SymboleSwiadectwToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents DefinicjeSzablonowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PowiazwaniaSzablonowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator18 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ImportSzablonuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ExportSzablonuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator19 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents KalkulatorTekstuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents OpcjeSwiadectwaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PrzydzialWychowawstwToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ToolStripSeparator20 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents SkalaOcenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents OpisyOcenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents KolumnyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PrzydzialPrzedmiotowDoSzkolToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator21 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents PlanLekcjiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ObsadaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents tlpCommonData As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents lblRokSzkolny As System.Windows.Forms.Label
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents lblSchoolName As System.Windows.Forms.Label
  Friend WithEvents KonfiguracjaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents HarmonogramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents TematToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator26 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ToolStripSeparator27 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents GrupyPrzedmiotoweToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator28 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents LiczbaGodzinToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents AnalizaOcenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents WykazNdstToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents NadzorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ZastepstwoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator29 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents KalibracjaWydrukuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents LiczbaGodzinWgKlasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents LiczbaGodzinWgNauczycielaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents MinLekcjaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator30 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents UserActivityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents TematByDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents TematByBelferToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents statSSLMode As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents cmdTemat As System.Windows.Forms.ToolStripButton
  Friend WithEvents cmdTematByNauczyciel As System.Windows.Forms.ToolStripButton
  Friend WithEvents ToolStripSeparator31 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents cmdWynikiCzastkowe As System.Windows.Forms.ToolStripButton
  Friend WithEvents ToolStripSeparator22 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents cmdAbsencja As System.Windows.Forms.ToolStripButton
  Friend WithEvents ToolStripSeparator23 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents cmdUwaga As System.Windows.Forms.ToolStripButton
  Friend WithEvents ToolStripSeparator24 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents cmdZagrozenia As System.Windows.Forms.ToolStripButton
  Friend WithEvents ToolStripSeparator25 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents KonfiguracjaToolStripButton As System.Windows.Forms.ToolStripButton
  Friend WithEvents cmdWyloguj As System.Windows.Forms.ToolStripButton
  Friend WithEvents cmdCloseProgram As System.Windows.Forms.ToolStripButton
  Friend WithEvents QuickAccessToolStrip As System.Windows.Forms.ToolStrip
  Friend WithEvents ManagePlanLekcjiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents cmdOcenyZachowania As System.Windows.Forms.ToolStripButton
  Friend WithEvents KlasyfikacjaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents FrekwencjaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ZestawienieKlasyfikacjiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents TerminarzToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents cmdTerminarz As System.Windows.Forms.ToolStripButton
  Friend WithEvents ToolStripSeparator33 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ToolStripSeparator32 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents NauczanieIndywidualneToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator34 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents AdminToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ServiceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents MoveResultToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents SQLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents AbsencjaByMonthToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents TableSetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PoprawkaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents StudentMakeupAllowedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents WynikiPoprawkoweToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents StudentProjektToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents TematProjektToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ZarzadzanieuzytkownikamiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents UprawnieniaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ZmianaHasla2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ApplicationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator35 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ReklamacjaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents LoggingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator36 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ParentLoggingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents OutofdatePrivilageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents CurrentConnectionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator37 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ToolStripSeparator38 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents LockResultColumnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator39 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents UzasadnieniaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator40 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents WykazNdpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
