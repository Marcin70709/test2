﻿Imports System.Windows.Forms

Public Class dlgWait


End Class
